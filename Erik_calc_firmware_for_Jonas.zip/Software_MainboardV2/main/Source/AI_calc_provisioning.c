/*

ChatGPT Hardware Hack for calculators: Software V2

© 2026 Jonas Heselschwerdt
Licensed under GPLv3

provisioning.c: Local setup web server

*/

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "esp_http_server.h"
#include "esp_log.h"

#include "AI_calc_LLMs.h"
#include "AI_calc_camera.h"
#include "AI_calc_network.h"
#include "AI_calc_provisioning.h"

#define PROVISIONING_FORM_MAX_LENGTH 1400

static const char *TAG = "Provisioning";
static httpd_handle_t provisioning_server;

static const char setup_page[] =
    "<!doctype html><html lang=\"en\"><head>"
    "<meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">"
    "<title>Jonas Calc Setup</title><style>"
    ":root{color-scheme:light dark;font-family:system-ui,sans-serif}"
    "body{margin:0;background:#101418;color:#eef2f5}main{max-width:520px;margin:auto;padding:24px}"
    "section{background:#1b2229;border:1px solid #34414c;border-radius:14px;padding:18px;margin:16px 0}"
    "h1{font-size:1.65rem;margin:.25rem 0}h2{font-size:1.1rem;margin:0 0 12px}"
    "label{display:block;margin:12px 0 6px}input,select,button{box-sizing:border-box;width:100%;font:inherit;"
    "padding:12px;border-radius:9px;border:1px solid #52616d;background:#0e1317;color:#fff}"
    "button{margin-top:16px;background:#2b73d2;border:0;font-weight:700}"
    "small{display:block;color:#b9c4cc;line-height:1.45}.show{display:flex;gap:8px;align-items:center;margin-top:8px}"
    ".show input{width:auto}.show label{margin:0}</style></head><body><main>"
    "<h1>Jonas Calc Setup</h1><small>Values are saved directly to the calculator. "
    "Leave a field empty to keep its current value.</small>"
    "<form method=\"post\" action=\"/save\">"
    "<section><h2>Wi-Fi</h2>"
    "<label for=\"slot\">Save slot</label><select id=\"slot\" name=\"slot\">"
    "<option value=\"0\">Slot 1</option><option value=\"1\">Slot 2</option>"
    "<option value=\"2\">Slot 3</option><option value=\"3\">Slot 4</option>"
    "<option value=\"4\">Slot 5</option><option value=\"5\">Slot 6</option>"
    "<option value=\"6\">Slot 7</option><option value=\"7\">Slot 8</option>"
    "<option value=\"8\">Slot 9</option><option value=\"9\">Slot 10</option>"
    "<option value=\"10\">Slot 11</option><option value=\"11\">Slot 12</option>"
    "<option value=\"12\">Slot 13</option><option value=\"13\">Slot 14</option>"
    "<option value=\"14\">Slot 15</option><option value=\"15\">Slot 16</option>"
    "</select><label for=\"ssid\">Network name (SSID)</label>"
    "<input id=\"ssid\" name=\"ssid\" maxlength=\"32\" autocomplete=\"off\">"
    "<label for=\"wifi_password\">Wi-Fi password</label>"
    "<input id=\"wifi_password\" name=\"wifi_password\" type=\"password\" maxlength=\"64\" autocomplete=\"new-password\">"
    "<div class=\"show\"><input id=\"no_password\" name=\"no_password\" type=\"checkbox\" value=\"1\">"
    "<label for=\"no_password\">This network has no password</label></div>"
    "</section><section><h2>OpenAI</h2><label for=\"openai_key\">API key</label>"
    "<input id=\"openai_key\" name=\"openai_key\" type=\"password\" maxlength=\"280\" autocomplete=\"off\">"
    "<div class=\"show\"><input id=\"show_values\" type=\"checkbox\"><label for=\"show_values\">Show passwords while typing</label></div>"
    "</section><button type=\"submit\">Save settings</button></form>"
    "<form method=\"post\" action=\"/camera/test\"><section><h2>Camera test</h2>"
    "<small>Take a picture with the calculator camera and display it on this device.</small>"
    "<button type=\"submit\">Test camera</button></section></form>"
    "<small>After saving, turn Setup AP off in the calculator's Wi-Fi Settings menu.</small>"
    "<script>document.getElementById('show_values').addEventListener('change',function(){"
    "for(const id of ['wifi_password','openai_key'])document.getElementById(id).type=this.checked?'text':'password';});"
    "document.getElementById('no_password').addEventListener('change',function(){"
    "const p=document.getElementById('wifi_password');p.disabled=this.checked;if(this.checked)p.value='';});</script>"
    "</main></body></html>";

static const char saved_page[] =
    "<!doctype html><html lang=\"en\"><head><meta charset=\"utf-8\">"
    "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>Saved</title>"
    "<style>body{font-family:system-ui,sans-serif;max-width:520px;margin:40px auto;padding:20px;"
    "background:#101418;color:#eef2f5}a{color:#70adff}</style></head><body>"
    "<h1>Settings saved</h1><p>The submitted values are now in calculator memory.</p>"
    "<p>Turn <b>Setup AP</b> off on the calculator when finished.</p><p><a href=\"/\">Back to setup</a></p>"
    "</body></html>";

static const char error_page[] =
    "<!doctype html><html lang=\"en\"><head><meta charset=\"utf-8\">"
    "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>Not saved</title>"
    "<style>body{font-family:system-ui,sans-serif;max-width:520px;margin:40px auto;padding:20px;"
    "background:#101418;color:#eef2f5}a{color:#70adff}</style></head><body>"
    "<h1>Could not save</h1><p>Check the field lengths and try again.</p>"
    "<p><a href=\"/\">Back to setup</a></p></body></html>";

static const char camera_success_page[] =
    "<!doctype html><html lang=\"en\"><head><meta charset=\"utf-8\">"
    "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>Camera test</title>"
    "<style>body{font-family:system-ui,sans-serif;max-width:700px;margin:24px auto;padding:20px;"
    "background:#101418;color:#eef2f5}img{display:block;width:100%;height:auto;border-radius:12px;"
    "background:#000}form{margin-top:18px}button{box-sizing:border-box;width:100%;font:inherit;padding:12px;"
    "border:0;border-radius:9px;background:#2b73d2;color:#fff;font-weight:700}a{color:#70adff}</style>"
    "</head><body><h1>Camera test complete</h1><p>The image below was just captured by the calculator.</p>"
    "<img src=\"/camera.jpg\" alt=\"Calculator camera test picture\">"
    "<form method=\"post\" action=\"/camera/test\"><button type=\"submit\">Take another picture</button></form>"
    "<p><a href=\"/\">Back to setup</a></p></body></html>";

static const char camera_error_page[] =
    "<!doctype html><html lang=\"en\"><head><meta charset=\"utf-8\">"
    "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>Camera test failed</title>"
    "<style>body{font-family:system-ui,sans-serif;max-width:520px;margin:40px auto;padding:20px;"
    "background:#101418;color:#eef2f5}a{color:#70adff}</style></head><body>"
    "<h1>Camera test failed</h1><p>The calculator could not initialize the camera or capture an image. "
    "Check the camera ribbon connection and try again.</p><p><a href=\"/\">Back to setup</a></p>"
    "</body></html>";

static const char camera_storage_full_page[] =
    "<!doctype html><html lang=\"en\"><head><meta charset=\"utf-8\">"
    "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>Camera storage full</title>"
    "<style>body{font-family:system-ui,sans-serif;max-width:520px;margin:40px auto;padding:20px;"
    "background:#101418;color:#eef2f5}a{color:#70adff}</style></head><body>"
    "<h1>Camera storage full</h1><p>Delete the saved camera pictures from the calculator, then run the test again.</p>"
    "<p><a href=\"/\">Back to setup</a></p></body></html>";

static int hex_value(char c){

    if ((c >= '0') && (c <= '9')){
        return c - '0';
    }
    c = (char)tolower((unsigned char)c);
    if ((c >= 'a') && (c <= 'f')){
        return c - 'a' + 10;
    }
    return -1;
}

static esp_err_t url_decode(const char *encoded, size_t encoded_length, char *decoded, size_t decoded_size){

    size_t output_index = 0;
    for (size_t i = 0; i < encoded_length; i++){
        char value = encoded[i];
        if (value == '+'){
            value = ' ';
        }
        else if (value == '%'){
            if ((i + 2) >= encoded_length){
                return ESP_ERR_INVALID_ARG;
            }
            int high = hex_value(encoded[i + 1]);
            int low = hex_value(encoded[i + 2]);
            if ((high < 0) || (low < 0)){
                return ESP_ERR_INVALID_ARG;
            }
            value = (char)((high << 4) | low);
            i += 2;
        }
        if ((value == '\0') || ((output_index + 1) >= decoded_size)){
            return ESP_ERR_INVALID_SIZE;
        }
        decoded[output_index++] = value;
    }
    decoded[output_index] = '\0';
    return ESP_OK;
}

static esp_err_t form_value(const char *body, const char *name, char *value, size_t value_size){

    size_t name_length = strlen(name);
    const char *field = body;
    while (*field != '\0'){
        const char *field_end = strchr(field,'&');
        if (field_end == NULL){
            field_end = field + strlen(field);
        }
        const char *equals = memchr(field,'=',(size_t)(field_end - field));
        if ((equals != NULL) && ((size_t)(equals - field) == name_length) &&
            (strncmp(field,name,name_length) == 0)){
            return url_decode(equals + 1,(size_t)(field_end - equals - 1),value,value_size);
        }
        if (*field_end == '\0'){
            break;
        }
        field = field_end + 1;
    }
    value[0] = '\0';
    return ESP_ERR_NOT_FOUND;
}

static esp_err_t setup_page_get_handler(httpd_req_t *request){

    httpd_resp_set_type(request,"text/html; charset=utf-8");
    httpd_resp_set_hdr(request,"Cache-Control","no-store");
    return httpd_resp_send(request,setup_page,HTTPD_RESP_USE_STRLEN);
}

static esp_err_t setup_page_save_handler(httpd_req_t *request){

    if ((request->content_len <= 0) || (request->content_len >= PROVISIONING_FORM_MAX_LENGTH)){
        httpd_resp_set_status(request,"400 Bad Request");
        httpd_resp_set_type(request,"text/html; charset=utf-8");
        return httpd_resp_send(request,error_page,HTTPD_RESP_USE_STRLEN);
    }

    char *body = calloc(1,(size_t)request->content_len + 1);
    if (body == NULL){
        return httpd_resp_send_500(request);
    }
    size_t received = 0;
    while (received < (size_t)request->content_len){
        int result = httpd_req_recv(request,body + received,(size_t)request->content_len - received);
        if (result <= 0){
            free(body);
            return httpd_resp_send_500(request);
        }
        received += (size_t)result;
    }
    body[received] = '\0';

    char slot_text[4] = {0};
    char ssid[WIFI_MAX_SSID_LENGTH + 1] = {0};
    char wifi_password[WIFI_MAX_PASSW_LENGTH + 1] = {0};
    char openai_key[API_KEY_MAX_LENGTH + 1] = {0};
    char no_password[4] = {0};

    esp_err_t slot_result = form_value(body,"slot",slot_text,sizeof(slot_text));
    esp_err_t ssid_result = form_value(body,"ssid",ssid,sizeof(ssid));
    esp_err_t password_result = form_value(body,"wifi_password",wifi_password,sizeof(wifi_password));
    esp_err_t key_result = form_value(body,"openai_key",openai_key,sizeof(openai_key));
    esp_err_t no_password_result = form_value(body,"no_password",no_password,sizeof(no_password));
    // Erik: "This network has no password" ticked -> save an empty password (= open network).
    // Without the tick an empty password is rejected, so a forgotten password is not saved as an open network.
    bool open_network = (no_password_result == ESP_OK) && (no_password[0] == '1');
    if (open_network){
        wifi_password[0] = '\0';
        password_result = ESP_OK;
    }
    memset(body,0,received);
    free(body);

    bool attempted_save = false;
    bool save_ok = true;
    if ((ssid_result == ESP_OK) && (ssid[0] != '\0')){
        char *slot_end = NULL;
        long slot = strtol(slot_text,&slot_end,10);
        if ((slot_result != ESP_OK) || (password_result != ESP_OK) || (slot_end == slot_text) ||
            ((!open_network) && (wifi_password[0] == '\0')) ||
            (*slot_end != '\0') || (slot < 0) || (slot >= WIFI_MAX_STORED_LOGINDATA)){
            save_ok = false;
        }
        else{
            attempted_save = true;
            if (wifi_add_login_credentials(ssid,wifi_password,(uint8_t)slot) != ESP_OK){
                save_ok = false;
            }
        }
    }
    else if ((ssid_result != ESP_OK) && (ssid_result != ESP_ERR_NOT_FOUND)){
        save_ok = false;
    }

    if ((key_result == ESP_OK) && (openai_key[0] != '\0')){
        attempted_save = true;
        if (save_API_Key(AI_MODEL_OPENAI,openai_key) != ESP_OK){
            save_ok = false;
        }
    }
    else if ((key_result != ESP_OK) && (key_result != ESP_ERR_NOT_FOUND)){
        save_ok = false;
    }

    memset(wifi_password,0,sizeof(wifi_password));
    memset(openai_key,0,sizeof(openai_key));

    httpd_resp_set_type(request,"text/html; charset=utf-8");
    httpd_resp_set_hdr(request,"Cache-Control","no-store");
    if (save_ok && attempted_save){
        return httpd_resp_send(request,saved_page,HTTPD_RESP_USE_STRLEN);
    }
    httpd_resp_set_status(request,"400 Bad Request");
    return httpd_resp_send(request,error_page,HTTPD_RESP_USE_STRLEN);
}

static esp_err_t setup_page_redirect_handler(httpd_req_t *request){

    httpd_resp_set_status(request,"302 Found");
    httpd_resp_set_hdr(request,"Location","/");
    return httpd_resp_send(request,NULL,0);
}

static esp_err_t camera_test_post_handler(httpd_req_t *request){

    uint8_t picture_count = 0;
    if (get_saved_pics(&picture_count) != ESP_OK){
        httpd_resp_set_status(request,"500 Internal Server Error");
        httpd_resp_set_type(request,"text/html; charset=utf-8");
        return httpd_resp_send(request,camera_error_page,HTTPD_RESP_USE_STRLEN);
    }
    if (picture_count >= MAX_SAVED_PICTURES){
        httpd_resp_set_status(request,"507 Insufficient Storage");
        httpd_resp_set_type(request,"text/html; charset=utf-8");
        return httpd_resp_send(request,camera_storage_full_page,HTTPD_RESP_USE_STRLEN);
    }
    if (camera_take_picture() != ESP_OK){
        httpd_resp_set_status(request,"500 Internal Server Error");
        httpd_resp_set_type(request,"text/html; charset=utf-8");
        return httpd_resp_send(request,camera_error_page,HTTPD_RESP_USE_STRLEN);
    }
    httpd_resp_set_type(request,"text/html; charset=utf-8");
    httpd_resp_set_hdr(request,"Cache-Control","no-store");
    return httpd_resp_send(request,camera_success_page,HTTPD_RESP_USE_STRLEN);
}

static esp_err_t camera_latest_get_handler(httpd_req_t *request){

    uint8_t picture_count = 0;
    if ((get_saved_pics(&picture_count) != ESP_OK) || (picture_count == 0)){
        httpd_resp_set_status(request,"404 Not Found");
        return httpd_resp_send(request,"No camera picture available\n",HTTPD_RESP_USE_STRLEN);
    }

    char filename[64];
    snprintf(filename,sizeof(filename),"/littlefs/cam/camera[%03u].jpg",picture_count - 1);
    FILE *file = fopen(filename,"rb");
    if (file == NULL){
        httpd_resp_set_status(request,"404 Not Found");
        return httpd_resp_send(request,"Camera picture not found\n",HTTPD_RESP_USE_STRLEN);
    }

    httpd_resp_set_type(request,"image/jpeg");
    httpd_resp_set_hdr(request,"Cache-Control","no-store, no-cache, must-revalidate");
    char buffer[1024];
    size_t bytes_read;
    esp_err_t result = ESP_OK;
    while ((bytes_read = fread(buffer,1,sizeof(buffer),file)) > 0){
        result = httpd_resp_send_chunk(request,buffer,bytes_read);
        if (result != ESP_OK){
            break;
        }
    }
    fclose(file);
    if (result != ESP_OK){
        return result;
    }
    return httpd_resp_send_chunk(request,NULL,0);
}

esp_err_t provisioning_server_start(void){

    if (provisioning_server != NULL){
        return ESP_OK;
    }
    httpd_config_t config = HTTPD_DEFAULT_CONFIG();
    config.server_port = 80;
    config.max_uri_handlers = 5;
    config.stack_size = 8192;
    config.uri_match_fn = httpd_uri_match_wildcard;

    esp_err_t result = httpd_start(&provisioning_server,&config);
    if (result != ESP_OK){
        provisioning_server = NULL;
        return result;
    }

    httpd_uri_t root = {
        .uri = "/",
        .method = HTTP_GET,
        .handler = setup_page_get_handler,
        .user_ctx = NULL
    };
    httpd_uri_t save = {
        .uri = "/save",
        .method = HTTP_POST,
        .handler = setup_page_save_handler,
        .user_ctx = NULL
    };
    httpd_uri_t camera_test = {
        .uri = "/camera/test",
        .method = HTTP_POST,
        .handler = camera_test_post_handler,
        .user_ctx = NULL
    };
    httpd_uri_t camera_latest = {
        .uri = "/camera.jpg",
        .method = HTTP_GET,
        .handler = camera_latest_get_handler,
        .user_ctx = NULL
    };
    httpd_uri_t redirect = {
        .uri = "/*",
        .method = HTTP_GET,
        .handler = setup_page_redirect_handler,
        .user_ctx = NULL
    };
    if ((httpd_register_uri_handler(provisioning_server,&root) != ESP_OK) ||
        (httpd_register_uri_handler(provisioning_server,&save) != ESP_OK) ||
        (httpd_register_uri_handler(provisioning_server,&camera_test) != ESP_OK) ||
        (httpd_register_uri_handler(provisioning_server,&camera_latest) != ESP_OK) ||
        (httpd_register_uri_handler(provisioning_server,&redirect) != ESP_OK)){
        provisioning_server_stop();
        return ESP_FAIL;
    }
    ESP_LOGI(TAG,"Setup web server started");
    return ESP_OK;
}

void provisioning_server_stop(void){

    if (provisioning_server != NULL){
        httpd_stop(provisioning_server);
        provisioning_server = NULL;
        // Erik: camera test pictures are saved in the normal picture storage and would otherwise be
        // sent along with the next question -> delete them when the setup AP is turned off.
        delete_camera_directory();
        ESP_LOGI(TAG,"Setup web server stopped");
    }
}
