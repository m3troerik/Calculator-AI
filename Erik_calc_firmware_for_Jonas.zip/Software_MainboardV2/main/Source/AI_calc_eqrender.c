/*
ChatGPT Hardware Hack for calculators: Software V2
eqrender: on-device rendering of the LaTeX subset the firmware asks the AI to use.
Added by Erik (2026). Licensed under GPLv3 like the rest of the software.

How it works:
1. A small recursive-descent parser turns the LaTeX string into a tree of nodes
   (characters, words, symbols, fractions, roots, scripts, accents, brackets, spaces).
2. A layout pass measures every node (width, ascent, descent) for one of four font sizes.
3. The largest font size that fits 128 x 40 px is drawn with U8g2 into an off-screen buffer,
   which is then converted to XBM. Equations that are too wide are split into several bitmaps.
Everything uses fixed-size static memory; bad or unsupported input can never crash it.
*/

#include <string.h>
#include <stdint.h>
#include "u8g2.h"
#include "AI_calc_eqrender.h"

// ---------------------------------------------------------------------------------------
// Settings
// ---------------------------------------------------------------------------------------

#define EQR_MAX_NODES 320
#define EQR_MAX_DEPTH 12
#define EQR_NO_NODE (-1)
#define EQR_TILE_ROWS (EQR_HEIGHT / 8)
#define EQR_ARROW_W 8          // space reserved at the right edge for the "continues" arrow

// Font sets (big to small). Index: [set][level], level 0 = normal, 1 = script, 2 = script of script
#define EQR_FONT_SETS 4
static const uint8_t* const eqr_fonts[EQR_FONT_SETS][3] = {
    {u8g2_font_9x15_tr, u8g2_font_6x10_tr, u8g2_font_5x7_tr},
    {u8g2_font_7x13_tr, u8g2_font_5x8_tr,  u8g2_font_4x6_tr},
    {u8g2_font_6x10_tr, u8g2_font_5x7_tr,  u8g2_font_4x6_tr},
    {u8g2_font_5x7_tr,  u8g2_font_4x6_tr,  u8g2_font_4x6_tr},
};
#define EQR_GREEK_FONT u8g2_font_unifont_t_greek

// ---------------------------------------------------------------------------------------
// Node tree
// ---------------------------------------------------------------------------------------

typedef enum {
    N_SEQ, N_CHAR, N_WORD, N_SYM, N_FRAC, N_SQRT, N_SCRIPT, N_ACCENT, N_DELIM, N_SPACE
} eqr_type_t;

typedef enum { C_ORD, C_BIN, C_REL, C_PUNCT, C_OPEN, C_CLOSE, C_FUNC } eqr_class_t;

typedef enum {
    S_SUM, S_PROD, S_INT, S_INF, S_LE, S_GE, S_NEQ, S_APPROX, S_PM, S_MP,
    S_CDOT, S_TIMES, S_DIV, S_TO, S_LEFTARROW, S_DOTS, S_PARTIAL, S_DEGREE,
    S_CAP, S_CUP, S_PRIME
} eqr_sym_t;

typedef enum { A_HAT, A_BAR, A_VEC, A_DOT, A_TILDE } eqr_accent_t;

typedef struct {
    int8_t  type;
    int8_t  cls;
    int8_t  lvl;        // set during layout
    int8_t  limits;     // 1: scripts above/below (sum, prod, lim)
    int16_t first;      // N_SEQ: first child
    int16_t next;       // next sibling in a sequence
    int16_t a, b, c;    // children (meaning depends on type)
    uint16_t cp;        // N_CHAR: code point, N_SYM: symbol, N_ACCENT: accent, N_DELIM: open char, N_SPACE: px
    uint16_t cp2;       // N_DELIM: close char
    char    txt[8];     // N_WORD
    // layout results
    int16_t w, asc, desc;
    int16_t pre;        // horizontal gap before this node inside its sequence
} eqr_node_t;

static eqr_node_t nodes[EQR_MAX_NODES];
static int16_t node_count;
static const char* src;
static uint16_t pos;
static uint8_t depth;
static uint8_t cur_set;

static u8g2_t eqr_u8g2;
static uint8_t eqr_buf[EQR_WIDTH * EQR_TILE_ROWS];
static uint8_t eqr_ready;

static int16_t new_node(eqr_type_t type){

    if (node_count >= EQR_MAX_NODES){
        return EQR_NO_NODE;
    }
    eqr_node_t* n = &nodes[node_count];
    memset(n,0,sizeof(*n));
    n->type = type;
    n->cls = C_ORD;
    n->first = n->next = n->a = n->b = n->c = EQR_NO_NODE;
    return node_count++;
}

static int16_t new_seq(void){ return new_node(N_SEQ); }

static void seq_append(int16_t seq, int16_t child){

    if ((seq == EQR_NO_NODE) || (child == EQR_NO_NODE)){
        return;
    }
    if (nodes[seq].first == EQR_NO_NODE){
        nodes[seq].first = child;
        return;
    }
    int16_t i = nodes[seq].first;
    while (nodes[i].next != EQR_NO_NODE){
        i = nodes[i].next;
    }
    nodes[i].next = child;
}

// ---------------------------------------------------------------------------------------
// Parser
// ---------------------------------------------------------------------------------------

static char peek(void){ return src[pos]; }

static void skip_spaces(void){
    while ((src[pos] == ' ') || (src[pos] == '\t') || (src[pos] == '\n') || (src[pos] == '\r')){
        pos++;
    }
}

typedef struct { const char* name; uint16_t cp; } eqr_greek_t;
static const eqr_greek_t greek[] = {
    {"alpha",0x3b1},{"beta",0x3b2},{"gamma",0x3b3},{"delta",0x3b4},{"epsilon",0x3b5},{"varepsilon",0x3b5},
    {"zeta",0x3b6},{"eta",0x3b7},{"theta",0x3b8},{"vartheta",0x3b8},{"iota",0x3b9},{"kappa",0x3ba},
    {"lambda",0x3bb},{"mu",0x3bc},{"nu",0x3bd},{"xi",0x3be},{"pi",0x3c0},{"rho",0x3c1},{"sigma",0x3c3},
    {"tau",0x3c4},{"upsilon",0x3c5},{"phi",0x3c6},{"varphi",0x3c6},{"chi",0x3c7},{"psi",0x3c8},{"omega",0x3c9},
    {"Gamma",0x393},{"Delta",0x394},{"Theta",0x398},{"Lambda",0x39b},{"Xi",0x39e},{"Pi",0x3a0},
    {"Sigma",0x3a3},{"Phi",0x3a6},{"Psi",0x3a8},{"Omega",0x3a9},
};

typedef struct { const char* name; int8_t sym; int8_t cls; int8_t limits; } eqr_symdef_t;
static const eqr_symdef_t symdefs[] = {
    {"sum",S_SUM,C_ORD,1},{"prod",S_PROD,C_ORD,1},{"int",S_INT,C_ORD,0},{"oint",S_INT,C_ORD,0},
    {"infty",S_INF,C_ORD,0},{"le",S_LE,C_REL,0},{"leq",S_LE,C_REL,0},{"ge",S_GE,C_REL,0},{"geq",S_GE,C_REL,0},
    {"neq",S_NEQ,C_REL,0},{"ne",S_NEQ,C_REL,0},{"approx",S_APPROX,C_REL,0},{"pm",S_PM,C_BIN,0},
    {"mp",S_MP,C_BIN,0},{"cdot",S_CDOT,C_BIN,0},{"times",S_TIMES,C_BIN,0},{"div",S_DIV,C_BIN,0},
    {"to",S_TO,C_REL,0},{"rightarrow",S_TO,C_REL,0},{"Rightarrow",S_TO,C_REL,0},{"implies",S_TO,C_REL,0},
    {"leftarrow",S_LEFTARROW,C_REL,0},{"ldots",S_DOTS,C_ORD,0},{"cdots",S_DOTS,C_ORD,0},{"dots",S_DOTS,C_ORD,0},
    {"partial",S_PARTIAL,C_ORD,0},{"circ",S_DEGREE,C_ORD,0},{"degree",S_DEGREE,C_ORD,0},
    {"cap",S_CAP,C_BIN,0},{"cup",S_CUP,C_BIN,0},{"prime",S_PRIME,C_ORD,0},
};

static const char* const funcs[] = {
    "sin","cos","tan","cot","sec","csc","arcsin","arccos","arctan","sinh","cosh","tanh",
    "log","ln","lg","exp","lim","max","min","det","gcd","mod","arg","deg",
};

static int16_t parse_seq(char stop);
static int16_t parse_atom(void);

static int16_t make_char(uint16_t cp, eqr_class_t cls){

    int16_t n = new_node(N_CHAR);
    if (n != EQR_NO_NODE){
        nodes[n].cp = cp;
        nodes[n].cls = cls;
    }
    return n;
}

static int16_t make_word(const char* text, uint8_t len, eqr_class_t cls){

    int16_t n = new_node(N_WORD);
    if (n != EQR_NO_NODE){
        if (len > sizeof(nodes[n].txt) - 1){
            len = sizeof(nodes[n].txt) - 1;
        }
        memcpy(nodes[n].txt,text,len);
        nodes[n].txt[len] = '\0';
        nodes[n].cls = cls;
    }
    return n;
}

static int16_t make_space(uint16_t px){

    int16_t n = new_node(N_SPACE);
    if (n != EQR_NO_NODE){
        nodes[n].cp = px;
    }
    return n;
}

// Single argument: {group}, \command or one character
static int16_t parse_arg(void){

    skip_spaces();
    if (peek() == '{'){
        pos++;
        int16_t g = parse_seq('}');
        if (peek() == '}'){
            pos++;
        }
        return g;
    }
    if (peek() == '\0'){
        return new_seq();
    }
    return parse_atom();
}

// \text{...}: keep characters and spaces as they are
static int16_t parse_text_arg(void){

    int16_t seq = new_seq();
    skip_spaces();
    if (peek() != '{'){
        return seq;
    }
    pos++;
    while ((peek() != '\0') && (peek() != '}')){
        if (peek() == ' '){
            seq_append(seq,make_space(3));
        }
        else{
            seq_append(seq,make_char((uint8_t)peek(),C_ORD));
        }
        pos++;
    }
    if (peek() == '}'){
        pos++;
    }
    return seq;
}

// Is there a matching close bracket at the same brace depth before the group ends?
static uint8_t has_matching(char open, char close){

    int level = 0;
    int braces = 0;
    for (uint16_t i = pos + 1; src[i] != '\0'; i++){
        char ch = src[i];
        if (ch == '\\' && src[i+1] != '\0'){
            i++;            // skip escaped character (e.g. \{ or the 'r' of \right is harmless)
            continue;
        }
        if (ch == '{') braces++;
        else if (ch == '}'){
            if (braces == 0) return 0;
            braces--;
        }
        else if (braces == 0){
            if (ch == open) level++;
            else if (ch == close){
                if (level == 0) return 1;
                level--;
            }
        }
    }
    return 0;
}

static int16_t parse_command(void){

    // pos is at the character after the backslash
    char name[16];
    uint8_t len = 0;
    if (((peek() >= 'a') && (peek() <= 'z')) || ((peek() >= 'A') && (peek() <= 'Z'))){
        while ((((peek() >= 'a') && (peek() <= 'z')) || ((peek() >= 'A') && (peek() <= 'Z'))) && (len < sizeof(name) - 1)){
            name[len++] = peek();
            pos++;
        }
        while (((peek() >= 'a') && (peek() <= 'z')) || ((peek() >= 'A') && (peek() <= 'Z'))){
            pos++;      // overlong name, ignore the rest
        }
    }
    else if (peek() != '\0'){
        name[len++] = peek();
        pos++;
    }
    name[len] = '\0';

    // spacing and escaped characters
    if (len == 1 && !((name[0] >= 'a' && name[0] <= 'z') || (name[0] >= 'A' && name[0] <= 'Z'))){
        switch (name[0]){
            case ',': return make_space(2);
            case ':': return make_space(3);
            case ';': return make_space(4);
            case ' ': return make_space(4);
            case '!': return make_space(0);
            case '\\': return make_space(6);
            case '{': return make_char('{',C_OPEN);
            case '}': return make_char('}',C_CLOSE);
            case '|': return make_char('|',C_ORD);
            default: return make_char((uint8_t)name[0],C_ORD);
        }
    }
    if (!strcmp(name,"quad")) return make_space(8);
    if (!strcmp(name,"qquad")) return make_space(16);
    if (!strcmp(name,"left") || !strcmp(name,"right") || !strcmp(name,"displaystyle") ||
        !strcmp(name,"big") || !strcmp(name,"Big") || !strcmp(name,"bigl") || !strcmp(name,"bigr")){
        skip_spaces();
        if (peek() == '.'){
            pos++;
        }
        return make_space(0);
    }
    if (!strcmp(name,"in")){
        return make_char(0x3b5,C_REL);
    }
    if (!strcmp(name,"boxed") || !strcmp(name,"underline") || !strcmp(name,"mathbb") || !strcmp(name,"mathcal")){
        return parse_arg();
    }
    if (!strcmp(name,"%")){
        return make_char('%',C_ORD);
    }
    if (!strcmp(name,"frac") || !strcmp(name,"dfrac") || !strcmp(name,"tfrac")){
        int16_t n = new_node(N_FRAC);
        if (n == EQR_NO_NODE) return n;
        nodes[n].a = parse_arg();
        nodes[n].b = parse_arg();
        return n;
    }
    if (!strcmp(name,"sqrt")){
        int16_t n = new_node(N_SQRT);
        if (n == EQR_NO_NODE) return n;
        skip_spaces();
        if (peek() == '['){
            pos++;
            nodes[n].b = parse_seq(']');
            if (peek() == ']'){
                pos++;
            }
        }
        nodes[n].a = parse_arg();
        return n;
    }
    if (!strcmp(name,"text") || !strcmp(name,"mathrm") || !strcmp(name,"textrm") || !strcmp(name,"mbox") ||
        !strcmp(name,"operatorname") || !strcmp(name,"mathbf") || !strcmp(name,"mathit") || !strcmp(name,"textbf")){
        return parse_text_arg();
    }
    struct { const char* n; int8_t a; } accents[] = {
        {"hat",A_HAT},{"widehat",A_HAT},{"bar",A_BAR},{"overline",A_BAR},{"vec",A_VEC},
        {"overrightarrow",A_VEC},{"dot",A_DOT},{"tilde",A_TILDE},{"widetilde",A_TILDE}
    };
    for (uint8_t i = 0; i < sizeof(accents)/sizeof(accents[0]); i++){
        if (!strcmp(name,accents[i].n)){
            int16_t n = new_node(N_ACCENT);
            if (n == EQR_NO_NODE) return n;
            nodes[n].cp = (uint16_t)accents[i].a;
            nodes[n].a = parse_arg();
            return n;
        }
    }
    for (uint8_t i = 0; i < sizeof(greek)/sizeof(greek[0]); i++){
        if (!strcmp(name,greek[i].name)){
            return make_char(greek[i].cp,C_ORD);
        }
    }
    for (uint8_t i = 0; i < sizeof(symdefs)/sizeof(symdefs[0]); i++){
        if (!strcmp(name,symdefs[i].name)){
            int16_t n = new_node(N_SYM);
            if (n == EQR_NO_NODE) return n;
            nodes[n].cp = (uint16_t)symdefs[i].sym;
            nodes[n].cls = symdefs[i].cls;
            nodes[n].limits = symdefs[i].limits;
            return n;
        }
    }
    for (uint8_t i = 0; i < sizeof(funcs)/sizeof(funcs[0]); i++){
        if (!strcmp(name,funcs[i])){
            int16_t n = make_word(name,len,C_FUNC);
            if ((n != EQR_NO_NODE) && (!strcmp(name,"lim") || !strcmp(name,"max") || !strcmp(name,"min"))){
                nodes[n].limits = 1;
            }
            return n;
        }
    }
    // Unknown command: show its name so nothing silently disappears
    return make_word(name,len,C_ORD);
}

static int16_t parse_atom(void){

    if (depth >= EQR_MAX_DEPTH){
        // Too deeply nested: skip one character so parsing always makes progress
        if (peek() != '\0') pos++;
        return EQR_NO_NODE;
    }
    depth++;
    int16_t result = EQR_NO_NODE;
    char ch = peek();
    if (ch == '{'){
        pos++;
        result = parse_seq('}');
        if (peek() == '}') pos++;
    }
    else if (ch == '\\'){
        pos++;
        result = parse_command();
    }
    else if (((ch == '(') && has_matching('(',')')) || ((ch == '[') && has_matching('[',']'))){
        char close = (ch == '(') ? ')' : ']';
        pos++;
        int16_t n = new_node(N_DELIM);
        if (n != EQR_NO_NODE){
            nodes[n].cp = (uint8_t)ch;
            nodes[n].cp2 = (uint8_t)close;
            nodes[n].a = parse_seq(close);
            nodes[n].cls = C_ORD;
        }
        // parse_seq stops before "\right" + close is consumed as an empty space command, so
        // here we only need to consume the close character itself
        if (peek() == close) pos++;
        result = n;
    }
    else{
        pos++;
        switch (ch){
            case '+': result = make_char('+',C_BIN); break;
            case '-': result = make_char('-',C_BIN); break;
            case '*': { int16_t n = new_node(N_SYM); if (n != EQR_NO_NODE){ nodes[n].cp = S_CDOT; nodes[n].cls = C_BIN; } result = n; break; }
            case '=': case '<': case '>': result = make_char((uint8_t)ch,C_REL); break;
            case ',': case ';': result = make_char((uint8_t)ch,C_PUNCT); break;
            case '(': case '[': result = make_char((uint8_t)ch,C_OPEN); break;
            case ')': case ']': result = make_char((uint8_t)ch,C_CLOSE); break;
            case '\'': { int16_t n = new_node(N_SYM); if (n != EQR_NO_NODE){ nodes[n].cp = S_PRIME; } result = n; break; }
            default:
                if ((uint8_t)ch >= 0x20 && (uint8_t)ch < 0x7f){
                    result = make_char((uint8_t)ch,C_ORD);
                }
                else{
                    result = make_space(0);     // non-ASCII: ignore
                }
                break;
        }
    }
    depth--;
    return result;
}

static int16_t parse_seq(char stop){

    int16_t seq = new_seq();
    if (seq == EQR_NO_NODE){
        return seq;
    }
    while (1){
        skip_spaces();
        char ch = peek();
        if (ch == '\0') break;
        if (ch == stop) break;
        if ((ch == '}') && (stop == '\0')){
            pos++;                  // stray closing brace at top level: ignore it
            continue;
        }
        if ((ch == '}') && (stop != '}')){
            // unbalanced brace inside a bracket: stop here, caller will see it
            break;
        }
        // "\right)" ends a bracket group: let "\right" be eaten, the caller consumes ')'
        if ((ch == '\\') && (stop == ')' || stop == ']') && (strncmp(&src[pos],"\\right",6) == 0)){
            pos += 6;
            skip_spaces();
            if (peek() == stop) break;
            continue;
        }
        int16_t atom;
        if ((ch == '^') || (ch == '_')){
            atom = new_seq();       // script without base
        }
        else{
            uint16_t before = pos;
            atom = parse_atom();
            if (pos == before){
                pos++;              // safety: always progress
            }
        }
        // scripts
        skip_spaces();
        while ((peek() == '^') || (peek() == '_')){
            char s = peek();
            pos++;
            if (atom == EQR_NO_NODE || nodes[atom].type != N_SCRIPT){
                int16_t sc = new_node(N_SCRIPT);
                if (sc == EQR_NO_NODE) break;
                nodes[sc].a = atom;
                if (atom != EQR_NO_NODE){
                    nodes[sc].limits = nodes[atom].limits;
                }
                atom = sc;
            }
            depth++;
            int16_t arg = (depth < EQR_MAX_DEPTH) ? parse_arg() : EQR_NO_NODE;
            depth--;
            if (s == '^') nodes[atom].b = arg;
            else nodes[atom].c = arg;
            skip_spaces();
        }
        seq_append(seq,atom);
        if (node_count >= EQR_MAX_NODES){
            break;
        }
    }
    return seq;
}

// ---------------------------------------------------------------------------------------
// Layout
// ---------------------------------------------------------------------------------------

static void set_font(int lvl, uint8_t greek_font){

    if (lvl > 2) lvl = 2;
    if (lvl < 0) lvl = 0;
    u8g2_SetFont(&eqr_u8g2, greek_font ? EQR_GREEK_FONT : eqr_fonts[cur_set][lvl]);
}

static int16_t font_asc(int lvl){ set_font(lvl,0); return u8g2_GetAscent(&eqr_u8g2); }
static int16_t font_desc(int lvl){ set_font(lvl,0); return -u8g2_GetDescent(&eqr_u8g2); }
static int16_t axis_height(int lvl){ return (font_asc(lvl) + 1) / 2; }   // height of the fraction bar / minus sign

static int16_t text_width(const char* t, int lvl){

    set_font(lvl,0);
    int16_t w = 0;
    for (; *t; t++){
        w += u8g2_GetGlyphWidth(&eqr_u8g2,(uint8_t)*t);
    }
    return w;
}

static int16_t glyph_width(uint16_t cp, int lvl){

    set_font(lvl, cp >= 0x370);
    return u8g2_GetGlyphWidth(&eqr_u8g2,cp);
}

static int script_lvl(int lvl){ return (lvl < 2) ? lvl + 1 : 2; }

static void measure(int16_t n, int lvl, uint8_t in_frac);

static void measure_seq(int16_t n, int lvl, uint8_t in_frac){

    eqr_node_t* s = &nodes[n];
    s->w = 0; s->asc = 0; s->desc = 0;
    int16_t bin_gap = (lvl == 0) ? 2 : 1;
    int16_t rel_gap = (lvl == 0) ? 3 : 1;
    int8_t prev_cls = -1;
    for (int16_t i = s->first; i != EQR_NO_NODE; i = nodes[i].next){
        measure(i,lvl,in_frac);
        eqr_node_t* c = &nodes[i];
        int8_t cls = c->cls;
        // a binary operator at the start or after another operator is unary (e.g. "-x", "= -3")
        if ((cls == C_BIN) && ((prev_cls < 0) || (prev_cls == C_BIN) || (prev_cls == C_REL) ||
                               (prev_cls == C_OPEN) || (prev_cls == C_PUNCT))){
            cls = C_ORD;
            c->cls = C_ORD;
        }
        c->pre = 0;
        if (prev_cls >= 0){
            if ((cls == C_REL) || (prev_cls == C_REL)) c->pre = rel_gap;
            else if ((cls == C_BIN) || (prev_cls == C_BIN)) c->pre = bin_gap;
            else if (prev_cls == C_PUNCT) c->pre = 2;
            else if ((prev_cls == C_FUNC) && (cls != C_OPEN)) c->pre = (lvl == 0) ? 2 : 1;
            else if ((cls == C_FUNC) && (prev_cls == C_ORD)) c->pre = 1;
        }
        if (c->type == N_SPACE) {
            // explicit spaces do not get extra operator spacing
            c->pre = 0;
        }
        else {
            prev_cls = cls;
        }
        s->w += c->pre + c->w;
        if (c->asc > s->asc) s->asc = c->asc;
        if (c->desc > s->desc) s->desc = c->desc;
    }
    if (s->first == EQR_NO_NODE){
        // empty group (e.g. base of "^2" without base): give it the height of the font
        s->asc = font_asc(lvl);
    }
}

static void sym_metrics(eqr_node_t* s, int lvl){

    int16_t A = font_asc(lvl);
    int16_t ax = axis_height(lvl);
    int16_t h;
    switch (s->cp){
        case S_SUM: case S_PROD:
            h = (lvl == 0) ? A + 5 : A + 1;
            s->w = h * 3 / 4 + 1;
            s->asc = ax + h / 2; s->desc = h - s->asc;
            break;
        case S_INT:
            h = (lvl == 0) ? A + 7 : A + 2;
            s->w = (h > 14) ? 6 : 5;
            s->asc = ax + h / 2; s->desc = h - s->asc;
            break;
        case S_INF:{
            int16_t r = (A >= 9) ? 2 : 1;
            s->w = 4 * r + 3; s->asc = ax + r + 1; s->desc = 0;
            break; }
        case S_LE: case S_GE:{
            int16_t hh = ((A >= 9) ? 7 : 5) / 2;
            s->w = (A >= 9) ? 7 : 5;
            s->asc = ax + 1 + hh + 1;
            s->desc = (hh + 2 - ax > 0) ? hh + 2 - ax : 0;
            break; }
        case S_NEQ: case S_APPROX:
            s->w = (A >= 9) ? 7 : 5; s->asc = ax + 4; s->desc = (4 - ax > 0) ? 4 - ax : 0;
            break;
        case S_PM: case S_MP:
            s->w = (A >= 9) ? 7 : 5; s->asc = ax + s->w / 2 + 1; s->desc = 1;
            break;
        case S_CDOT:
            s->w = 2; s->asc = ax + 1; s->desc = 0;
            break;
        case S_TIMES: case S_DIV:
            s->w = (A >= 9) ? 6 : 4; s->asc = ax + s->w / 2 + 1; s->desc = 0;
            break;
        case S_TO: case S_LEFTARROW:
            s->w = (A >= 9) ? 9 : 6; s->asc = ax + 2; s->desc = 0;
            break;
        case S_DOTS:
            s->w = (A >= 9) ? 9 : 6; s->asc = 2; s->desc = 0;
            break;
        case S_PARTIAL:
            s->w = text_width("d",lvl); s->asc = A; s->desc = 0;
            break;
        case S_CAP: case S_CUP:
            s->w = (A >= 9) ? 6 : 5; s->asc = ax + 3; s->desc = (3 - ax > 0) ? 3 - ax : 0;
            break;
        case S_PRIME:
            s->w = 2; s->asc = A; s->desc = 0;
            break;
        case S_DEGREE:
        default:
            s->w = 3; s->asc = A; s->desc = 0;
            break;
    }
}

static void measure(int16_t n, int lvl, uint8_t in_frac){

    if (n == EQR_NO_NODE) return;
    eqr_node_t* s = &nodes[n];
    s->lvl = (int8_t)lvl;
    switch (s->type){
        case N_SEQ:
            measure_seq(n,lvl,in_frac);
            break;
        case N_CHAR:
            s->w = glyph_width(s->cp,lvl);
            if (s->cp >= 0x370){
                set_font(lvl,1);
                s->asc = u8g2_GetAscent(&eqr_u8g2);
                s->desc = -u8g2_GetDescent(&eqr_u8g2);
                // the greek font is larger than the script fonts: never let it look bigger than normal text
            }
            else{
                s->asc = font_asc(lvl);
                s->desc = font_desc(lvl);
            }
            break;
        case N_WORD:
            s->w = text_width(s->txt,lvl);
            s->asc = font_asc(lvl);
            s->desc = font_desc(lvl);
            break;
        case N_SPACE:
            s->w = (lvl == 0) ? s->cp : (s->cp * 2 + 2) / 3;
            s->asc = 0; s->desc = 0;
            break;
        case N_SYM:
            sym_metrics(s,lvl);
            break;
        case N_FRAC:{
            int child_lvl = (in_frac || lvl > 0) ? script_lvl(lvl) : lvl;
            measure(s->a,child_lvl,1);
            measure(s->b,child_lvl,1);
            int16_t nw = (s->a != EQR_NO_NODE) ? nodes[s->a].w : 0;
            int16_t dw = (s->b != EQR_NO_NODE) ? nodes[s->b].w : 0;
            int16_t na = (s->a != EQR_NO_NODE) ? nodes[s->a].asc + nodes[s->a].desc : 0;
            int16_t da = (s->b != EQR_NO_NODE) ? nodes[s->b].asc + nodes[s->b].desc : 0;
            int16_t ax = axis_height(lvl);
            s->w = ((nw > dw) ? nw : dw) + 2;
            s->asc = ax + 2 + na;
            s->desc = 2 + da - ax;
            if (s->desc < 0) s->desc = 0;
            break; }
        case N_SQRT:{
            measure(s->a,lvl,in_frac);
            int16_t bw = (s->a != EQR_NO_NODE) ? nodes[s->a].w : 0;
            int16_t ba = (s->a != EQR_NO_NODE) ? nodes[s->a].asc : font_asc(lvl);
            int16_t bd = (s->a != EQR_NO_NODE) ? nodes[s->a].desc : 0;
            int16_t H = ba + bd + 2;
            int16_t rw = H / 3 + 3;
            s->w = rw + bw + 1;
            s->asc = ba + 2;
            s->desc = bd;
            if (s->b != EQR_NO_NODE){
                measure(s->b,script_lvl(script_lvl(lvl)) ,in_frac);
                int16_t iw = nodes[s->b].w;
                if (iw > rw - 2){
                    s->w += iw - (rw - 2);
                }
                // index sits above the hook of the radical
                int16_t idx_top = -(s->asc) + H / 2 - 1 - nodes[s->b].desc - nodes[s->b].asc;
                if (-idx_top > s->asc) s->asc = -idx_top;
            }
            break; }
        case N_ACCENT:
            measure(s->a,lvl,in_frac);
            if (s->a != EQR_NO_NODE){
                s->w = nodes[s->a].w;
                s->asc = nodes[s->a].asc + ((s->cp == A_DOT) ? 2 : 3);
                s->desc = nodes[s->a].desc;
            }
            if (s->w < 3) s->w = 3;
            break;
        case N_DELIM:{
            measure(s->a,lvl,in_frac);
            int16_t bw = (s->a != EQR_NO_NODE) ? nodes[s->a].w : 0;
            int16_t ba = (s->a != EQR_NO_NODE) ? nodes[s->a].asc : 0;
            int16_t bd = (s->a != EQR_NO_NODE) ? nodes[s->a].desc : 0;
            int16_t fa = font_asc(lvl), fd = font_desc(lvl);
            if ((ba <= fa) && (bd <= fd + 1)){
                // normal height: font characters
                s->w = glyph_width(s->cp,lvl) + bw + glyph_width(s->cp2,lvl);
                s->asc = fa; s->desc = fd;
                s->limits = 0;      // reused as "tall" flag
            }
            else{
                int16_t h = ba + bd + 2;
                int16_t dw = (h > 20) ? 4 : 3;
                s->w = dw + 1 + bw + 1 + dw;
                s->asc = ba + 1;
                s->desc = bd + 1;
                s->limits = 1;
            }
            break; }
        case N_SCRIPT:{
            int sl = script_lvl(lvl);
            measure(s->a,lvl,in_frac);
            measure(s->b,sl,in_frac);
            measure(s->c,sl,in_frac);
            eqr_node_t* base = (s->a != EQR_NO_NODE) ? &nodes[s->a] : NULL;
            int16_t bw = base ? base->w : 0;
            int16_t ba = base ? base->asc : font_asc(lvl);
            int16_t bd = base ? base->desc : 0;
            int16_t supw = (s->b != EQR_NO_NODE) ? nodes[s->b].w : 0;
            int16_t subw = (s->c != EQR_NO_NODE) ? nodes[s->c].w : 0;
            s->cls = base ? base->cls : C_ORD;
            if (s->limits && (lvl == 0)){
                // limits above and below (sum, prod, lim)
                int16_t w = bw;
                if (supw > w) w = supw;
                if (subw > w) w = subw;
                s->w = w;
                s->asc = ba + ((s->b != EQR_NO_NODE) ? 1 + nodes[s->b].asc + nodes[s->b].desc : 0);
                s->desc = bd + ((s->c != EQR_NO_NODE) ? 1 + nodes[s->c].asc + nodes[s->c].desc : 0);
            }
            else{
                int16_t A = font_asc(lvl);
                uint8_t is_int = base && (base->type == N_SYM) && (base->cp == S_INT);
                int16_t sup_y = 0, sub_y = 0;   // baselines relative to base baseline (negative = up)
                if (s->b != EQR_NO_NODE){
                    sup_y = -(ba - (nodes[s->b].asc + 1) / 2);
                    if (sup_y > -(A / 2)) sup_y = -(A / 2);
                    if (is_int) sup_y = -(ba - nodes[s->b].asc);
                }
                if (s->c != EQR_NO_NODE){
                    sub_y = (nodes[s->c].asc + 1) / 2 + ((bd > 2) ? bd - 1 : 1);
                    if (is_int) sub_y = bd + 1;
                    if (s->b != EQR_NO_NODE){
                        int16_t gap = (sub_y - nodes[s->c].asc) - (sup_y + nodes[s->b].desc);
                        if (gap < 1) sub_y += 1 - gap;
                    }
                }
                // store script baselines in the unused fields
                s->cp = (uint16_t)(int16_t)sup_y;
                s->cp2 = (uint16_t)(int16_t)sub_y;
                s->w = bw + ((supw > subw) ? supw : subw) + (is_int ? 1 : 0);
                s->asc = ba;
                s->desc = bd;
                if (s->b != EQR_NO_NODE && (-sup_y + nodes[s->b].asc) > s->asc) s->asc = -sup_y + nodes[s->b].asc;
                if (s->c != EQR_NO_NODE && (sub_y + nodes[s->c].desc) > s->desc) s->desc = sub_y + nodes[s->c].desc;
                if (s->b != EQR_NO_NODE && (sup_y + nodes[s->b].desc) > s->desc) s->desc = sup_y + nodes[s->b].desc;
            }
            break; }
    }
}

// ---------------------------------------------------------------------------------------
// Drawing (with clipping to the 128 x 40 buffer)
// ---------------------------------------------------------------------------------------

static void px(int x, int y){

    if ((x < 0) || (y < 0) || (x >= EQR_WIDTH) || (y >= EQR_HEIGHT)) return;
    u8g2_DrawPixel(&eqr_u8g2,(u8g2_uint_t)x,(u8g2_uint_t)y);
}

static void hline(int x, int y, int w){ for (int i = 0; i < w; i++) px(x + i, y); }
static void vline(int x, int y, int h){ for (int i = 0; i < h; i++) px(x, y + i); }

static void line(int x0, int y0, int x1, int y1){

    int dx = (x1 > x0) ? x1 - x0 : x0 - x1;
    int dy = (y1 > y0) ? y0 - y1 : y1 - y0;     // negative
    int sx = (x0 < x1) ? 1 : -1;
    int sy = (y0 < y1) ? 1 : -1;
    int err = dx + dy;
    for (int guard = 0; guard < 512; guard++){
        px(x0,y0);
        if ((x0 == x1) && (y0 == y1)) break;
        int e2 = 2 * err;
        if (e2 >= dy){ err += dy; x0 += sx; }
        if (e2 <= dx){ err += dx; y0 += sy; }
    }
}

static void draw_glyph(uint16_t cp, int x, int y, int lvl){

    if ((x < 0) || (x >= EQR_WIDTH) || (y < 0) || (y >= EQR_HEIGHT + 20)) return;
    set_font(lvl, cp >= 0x370);
    u8g2_DrawGlyph(&eqr_u8g2,(u8g2_uint_t)x,(u8g2_uint_t)y,cp);
}

static void draw_text(const char* t, int x, int y, int lvl){

    for (; *t; t++){
        draw_glyph((uint8_t)*t,x,y,lvl);
        set_font(lvl,0);
        x += u8g2_GetGlyphWidth(&eqr_u8g2,(uint8_t)*t);
    }
}

static void draw(int16_t n, int x, int y);

static void draw_sym(eqr_node_t* s, int x, int y){

    int lvl = s->lvl;
    int ax = axis_height(lvl);
    int cy = y - ax;            // axis row
    int top = y - s->asc;
    int bot = y + s->desc - 1;
    int w = s->w;
    switch (s->cp){
        case S_SUM:
            hline(x, top, w - 1);
            hline(x, bot, w - 1);
            line(x, top, x + (w - 1) / 2, (top + bot) / 2);
            line(x + (w - 1) / 2, (top + bot) / 2, x, bot);
            px(x + w - 2, top + 1);
            px(x + w - 2, bot - 1);
            break;
        case S_PROD:
            hline(x, top, w - 1);
            vline(x + 1, top, bot - top + 1);
            vline(x + w - 3, top, bot - top + 1);
            break;
        case S_INT:{
            int mid = x + w / 2;
            vline(mid, top + 2, bot - top - 3);
            px(mid + 1, top + 1); px(mid + 2, top); px(mid + 3, top);
            px(mid - 1, bot - 1); px(mid - 2, bot); px(mid - 3, bot);
            break; }
        case S_INF:{
            int r = (font_asc(lvl) >= 9) ? 2 : 1;
            u8g2_DrawCircle(&eqr_u8g2, (u8g2_uint_t)(x + r + 1), (u8g2_uint_t)cy, (u8g2_uint_t)r, U8G2_DRAW_ALL);
            u8g2_DrawCircle(&eqr_u8g2, (u8g2_uint_t)(x + 3 * r + 2), (u8g2_uint_t)cy, (u8g2_uint_t)r, U8G2_DRAW_ALL);
            break; }
        case S_LE: case S_GE:{
            int h = w / 2;
            int tipy = cy - 1;
            if (s->cp == S_LE){ line(x + w - 1, tipy - h, x, tipy); line(x, tipy, x + w - 1, tipy + h); }
            else { line(x, tipy - h, x + w - 1, tipy); line(x + w - 1, tipy, x, tipy + h); }
            hline(x, tipy + h + 2, w);
            break; }
        case S_NEQ:
            hline(x, cy - 1, w); hline(x, cy + 1, w);
            line(x + w - 2, cy - 3, x + 1, cy + 3);
            break;
        case S_APPROX:
            for (int i = 0; i < w; i++){
                int o = ((i % 4) == 1) ? -1 : (((i % 4) == 3) ? 1 : 0);
                px(x + i, cy - 2 + o);
                px(x + i, cy + 2 + o);
            }
            break;
        case S_PM: case S_MP:{
            int h = w / 2;
            if (s->cp == S_PM){ hline(x, cy - 1, w); vline(x + h, cy - 1 - h, 2 * h + 1); hline(x, cy + h + 1, w); }
            else { hline(x, cy - h - 2, w); hline(x, cy + h - 1, w); vline(x + h, cy - h - 1, 2 * h + 1); }
            break; }
        case S_CDOT:
            px(x, cy); px(x + 1, cy); px(x, cy - 1); px(x + 1, cy - 1);
            break;
        case S_TIMES:
            line(x, cy - w / 2, x + w - 1, cy + w / 2 - 1);
            line(x, cy + w / 2 - 1, x + w - 1, cy - w / 2);
            break;
        case S_DIV:
            hline(x, cy, w);
            px(x + w / 2, cy - 2); px(x + w / 2, cy + 2);
            break;
        case S_TO:
            hline(x, cy, w);
            line(x + w - 1, cy, x + w - 3, cy - 2);
            line(x + w - 1, cy, x + w - 3, cy + 2);
            break;
        case S_LEFTARROW:
            hline(x, cy, w);
            line(x, cy, x + 2, cy - 2);
            line(x, cy, x + 2, cy + 2);
            break;
        case S_DOTS:
            px(x + 1, y - 1); px(x + w / 2, y - 1); px(x + w - 2, y - 1);
            break;
        case S_PARTIAL:
            draw_glyph('d', x, y, lvl);
            break;
        case S_CAP:
            vline(x, cy - 1, 4); vline(x + w - 2, cy - 1, 4); hline(x + 1, cy - 3, w - 3); px(x, cy - 2); px(x + w - 2, cy - 2);
            break;
        case S_CUP:
            vline(x, cy - 3, 4); vline(x + w - 2, cy - 3, 4); hline(x + 1, cy + 1, w - 3);
            break;
        case S_PRIME:
            line(x + 1, top, x, top + 2);
            break;
        case S_DEGREE:
        default:
            u8g2_DrawCircle(&eqr_u8g2, (u8g2_uint_t)(x + 1), (u8g2_uint_t)(y - font_asc(lvl) + 1), 1, U8G2_DRAW_ALL);
            break;
    }
}

static void draw_tall_delim(char ch, int x, int top, int bot, int dw){

    int h = bot - top + 1;
    switch (ch){
        case '(':
            vline(x + 1, top + 2, h - 4);
            px(x + 2, top + 1); px(x + 3, top); px(x + 2, bot - 1); px(x + 3, bot);
            if (dw > 3){ px(x + 1, top + 1); px(x + 1, bot - 1); }
            break;
        case ')':
            vline(x + dw - 2, top + 2, h - 4);
            px(x + dw - 3, top + 1); px(x + dw - 4, top); px(x + dw - 3, bot - 1); px(x + dw - 4, bot);
            if (dw > 3){ px(x + dw - 2, top + 1); px(x + dw - 2, bot - 1); }
            break;
        case '[':
            vline(x + 1, top, h); hline(x + 1, top, dw - 1); hline(x + 1, bot, dw - 1);
            break;
        case ']':
            vline(x + dw - 2, top, h); hline(x, top, dw - 1); hline(x, bot, dw - 1);
            break;
        default:
            vline(x + dw / 2, top, h);
            break;
    }
}

static void draw_seq_range(int16_t first, int16_t stop, int x, int y){

    for (int16_t i = first; (i != EQR_NO_NODE) && (i != stop); i = nodes[i].next){
        x += nodes[i].pre;
        draw(i,x,y);
        x += nodes[i].w;
    }
}

static void draw(int16_t n, int x, int y){

    if (n == EQR_NO_NODE) return;
    eqr_node_t* s = &nodes[n];
    switch (s->type){
        case N_SEQ:
            draw_seq_range(s->first,EQR_NO_NODE,x,y);
            break;
        case N_CHAR:
            draw_glyph(s->cp,x,y,s->lvl);
            break;
        case N_WORD:
            draw_text(s->txt,x,y,s->lvl);
            break;
        case N_SPACE:
            break;
        case N_SYM:
            draw_sym(s,x,y);
            break;
        case N_FRAC:{
            int ax = axis_height(s->lvl);
            int by = y - ax;
            hline(x, by, s->w);
            if (s->a != EQR_NO_NODE){
                eqr_node_t* a = &nodes[s->a];
                draw(s->a, x + (s->w - a->w) / 2, by - 2 - a->desc);
            }
            if (s->b != EQR_NO_NODE){
                eqr_node_t* b = &nodes[s->b];
                draw(s->b, x + (s->w - b->w) / 2, by + 2 + b->asc);
            }
            break; }
        case N_SQRT:{
            int16_t ba = (s->a != EQR_NO_NODE) ? nodes[s->a].asc : font_asc(s->lvl);
            int16_t bd = (s->a != EQR_NO_NODE) ? nodes[s->a].desc : 0;
            int16_t bw = (s->a != EQR_NO_NODE) ? nodes[s->a].w : 0;
            int16_t H = ba + bd + 2;
            int16_t rw = H / 3 + 3;
            int extra = 0;
            if (s->b != EQR_NO_NODE){
                int16_t iw = nodes[s->b].w;
                if (iw > rw - 2) extra = iw - (rw - 2);
            }
            int x0 = x + extra;
            int top = y - ba - 2;           // overline row
            int bot = y + bd - 1;           // lowest row of the radical
            int mid = top + H / 2;
            // hook, down stroke, up stroke, overline
            line(x0, mid, x0 + 1, mid - 1);
            line(x0 + 1, mid - 1, x0 + rw / 2, bot);
            line(x0 + rw / 2, bot, x0 + rw - 1, top);
            hline(x0 + rw - 1, top, bw + 2);
            draw(s->a, x0 + rw, y);
            if (s->b != EQR_NO_NODE){
                eqr_node_t* ix = &nodes[s->b];
                draw(s->b, x0 + rw - 2 - ix->w, mid - 1 - ix->desc);
            }
            break; }
        case N_ACCENT:{
            if (s->a == EQR_NO_NODE) break;
            eqr_node_t* a = &nodes[s->a];
            int ax0 = x + (s->w - a->w) / 2;
            draw(s->a, ax0, y);
            int top = y - a->asc - 1;
            int cx = x + s->w / 2;
            switch (s->cp){
                case A_HAT: px(cx - 1, top - 1); px(cx, top - 2); px(cx + 1, top - 1); break;
                case A_BAR: hline(x, top - 1, s->w); break;
                case A_VEC: hline(x, top - 1, s->w); px(x + s->w - 2, top - 2); px(x + s->w - 2, top); break;
                case A_DOT: px(cx, top); break;
                case A_TILDE: px(cx - 2, top - 1); px(cx - 1, top - 2); px(cx, top - 1); px(cx + 1, top); px(cx + 2, top - 1); break;
                default: break;
            }
            break; }
        case N_DELIM:{
            int16_t bw = (s->a != EQR_NO_NODE) ? nodes[s->a].w : 0;
            if (!s->limits){
                draw_glyph(s->cp, x, y, s->lvl);
                int wl = glyph_width(s->cp, s->lvl);
                draw(s->a, x + wl, y);
                draw_glyph(s->cp2, x + wl + bw, y, s->lvl);
            }
            else{
                int16_t h = s->asc + s->desc;
                int dw = ((h - 2) > 20) ? 4 : 3;
                int top = y - s->asc;
                int bot = y + s->desc - 1;
                draw_tall_delim((char)s->cp, x, top, bot, dw);
                draw(s->a, x + dw + 1, y);
                draw_tall_delim((char)s->cp2, x + dw + 1 + bw + 1, top, bot, dw);
            }
            break; }
        case N_SCRIPT:{
            eqr_node_t* base = (s->a != EQR_NO_NODE) ? &nodes[s->a] : NULL;
            int16_t bw = base ? base->w : 0;
            if (s->limits && (s->lvl == 0)){
                int16_t ba = base ? base->asc : 0;
                int16_t bd = base ? base->desc : 0;
                draw(s->a, x + (s->w - bw) / 2, y);
                if (s->b != EQR_NO_NODE){
                    eqr_node_t* p = &nodes[s->b];
                    draw(s->b, x + (s->w - p->w) / 2, y - ba - 1 - p->desc);
                }
                if (s->c != EQR_NO_NODE){
                    eqr_node_t* q = &nodes[s->c];
                    draw(s->c, x + (s->w - q->w) / 2, y + bd + 1 + q->asc);
                }
            }
            else{
                uint8_t is_int = base && (base->type == N_SYM) && (base->cp == S_INT);
                draw(s->a, x, y);
                int sx = x + bw + (is_int ? 1 : 0);
                if (s->b != EQR_NO_NODE) draw(s->b, sx, y + (int16_t)s->cp);
                if (s->c != EQR_NO_NODE) draw(s->c, sx, y + (int16_t)s->cp2);
            }
            break; }
    }
}

// ---------------------------------------------------------------------------------------
// Off-screen buffer and XBM conversion
// ---------------------------------------------------------------------------------------

static uint8_t eqr_noop_cb(u8x8_t *u8x8, uint8_t msg, uint8_t arg_int, void *arg_ptr){

    (void)u8x8; (void)msg; (void)arg_int; (void)arg_ptr;
    return 1;
}

static const u8x8_display_info_t eqr_display_info = {
    /* chip_enable_level = */ 0,
    /* chip_disable_level = */ 1,
    /* post_chip_enable_wait_ns = */ 0,
    /* pre_chip_disable_wait_ns = */ 0,
    /* reset_pulse_width_ms = */ 0,
    /* post_reset_wait_ms = */ 0,
    /* sda_setup_time_ns = */ 0,
    /* sck_pulse_width_ns = */ 0,
    /* sck_clock_hz = */ 4000000UL,
    /* spi_mode = */ 0,
    /* i2c_bus_clock_100kHz = */ 4,
    /* data_setup_time_ns = */ 0,
    /* write_pulse_width_ns = */ 0,
    /* tile_width = */ EQR_WIDTH / 8,
    /* tile_hight = */ EQR_TILE_ROWS,
    /* default_x_offset = */ 0,
    /* flipmode_x_offset = */ 0,
    /* pixel_width = */ EQR_WIDTH,
    /* pixel_height = */ EQR_HEIGHT
};

static uint8_t eqr_display_cb(u8x8_t *u8x8, uint8_t msg, uint8_t arg_int, void *arg_ptr){

    (void)arg_int; (void)arg_ptr;
    if (msg == U8X8_MSG_DISPLAY_SETUP_MEMORY){
        u8x8_d_helper_display_setup_memory(u8x8, &eqr_display_info);
    }
    return 1;
}

static void eqr_init(void){

    if (eqr_ready) return;
    // Separate U8g2 instance with its own buffer: never touches the real side display
    u8g2_SetupDisplay(&eqr_u8g2, eqr_display_cb, u8x8_cad_empty, eqr_noop_cb, eqr_noop_cb);
    u8g2_SetupBuffer(&eqr_u8g2, eqr_buf, EQR_TILE_ROWS, u8g2_ll_hvline_vertical_top_lsb, U8G2_R0);
    u8g2_SetFontPosBaseline(&eqr_u8g2);
    u8g2_SetFontMode(&eqr_u8g2, 1);
    u8g2_SetDrawColor(&eqr_u8g2, 1);
    eqr_ready = 1;
}

static void buffer_to_xbm(uint8_t* xbm){

    memset(xbm, 0, EQR_BYTES_PER_XBM);
    for (int y = 0; y < EQR_HEIGHT; y++){
        for (int x = 0; x < EQR_WIDTH; x++){
            if (eqr_buf[(y >> 3) * EQR_WIDTH + x] & (1 << (y & 7))){
                xbm[y * (EQR_WIDTH / 8) + (x >> 3)] |= (uint8_t)(1 << (x & 7));
            }
        }
    }
}

// Draws children [first, stop) of the root sequence centred into one XBM
static void render_line(int16_t first, int16_t stop, int16_t w, int16_t asc, int16_t desc, uint8_t continues, uint8_t* xbm){

    memset(eqr_buf, 0, sizeof(eqr_buf));
    int area = continues ? (EQR_WIDTH - EQR_ARROW_W) : EQR_WIDTH;
    int x = (area - w) / 2;
    if (x < 0) x = 0;
    int h = asc + desc;
    int y = (EQR_HEIGHT - h) / 2 + asc;
    if (h > EQR_HEIGHT) y = asc - (h - EQR_HEIGHT) / 2;
    draw_seq_range(first, stop, x, y);
    if (continues){
        // the equation is cut here because the screen is too narrow: arrow at the right edge,
        // the next screen continues the SAME notebook line
        int ay = y - axis_height(0);
        int ax = EQR_WIDTH - EQR_ARROW_W + 1;
        hline(ax, ay, EQR_ARROW_W - 1);
        line(EQR_WIDTH - 1, ay, EQR_WIDTH - 3, ay - 2);
        line(EQR_WIDTH - 1, ay, EQR_WIDTH - 3, ay + 2);
    }
    buffer_to_xbm(xbm);
}

uint8_t eqr_render_to_xbms(const char* latex, uint8_t* xbm_out, uint8_t max_xbms){

    if ((latex == NULL) || (xbm_out == NULL) || (max_xbms == 0)) return 0;
    eqr_init();
    // Parse
    node_count = 0;
    depth = 0;
    src = latex;
    pos = 0;
    int16_t root = parse_seq('\0');
    if ((root == EQR_NO_NODE) || (nodes[root].first == EQR_NO_NODE)) return 0;

    // Biggest font set that fits on one screen
    for (cur_set = 0; cur_set < EQR_FONT_SETS; cur_set++){
        measure(root, 0, 0);
        eqr_node_t* r = &nodes[root];
        if ((r->w <= EQR_WIDTH) && (r->asc + r->desc <= EQR_HEIGHT)){
            render_line(r->first, EQR_NO_NODE, r->w, r->asc, r->desc, 0, xbm_out);
            return 1;
        }
    }

    // Too wide: split into several lines at "=", "+", "-" (top level only).
    // Use the biggest set whose height fits, but not bigger than set 1 (readability vs. line count)
    for (cur_set = 1; cur_set < EQR_FONT_SETS - 1; cur_set++){
        measure(root, 0, 0);
        if (nodes[root].asc + nodes[root].desc <= EQR_HEIGHT) break;
    }
    measure(root, 0, 0);
    uint8_t count = 0;
    int16_t line_first = nodes[root].first;
    while ((line_first != EQR_NO_NODE) && (count < max_xbms)){
        int16_t w = 0, asc = 0, desc = 0;
        int16_t last_break = EQR_NO_NODE;   // node where a new line could start
        int16_t i = line_first;
        int16_t stop = EQR_NO_NODE;
        for (; i != EQR_NO_NODE; i = nodes[i].next){
            int16_t add = ((i == line_first) ? 0 : nodes[i].pre) + nodes[i].w;
            if ((i != line_first) && ((nodes[i].cls == C_REL) || (nodes[i].cls == C_BIN))){
                last_break = i;
            }
            if ((w + add > EQR_WIDTH - EQR_ARROW_W) && (i != line_first)){
                stop = (last_break != EQR_NO_NODE) ? last_break : i;
                break;
            }
            w += add;
        }
        // measure the chosen line
        w = 0; asc = 0; desc = 0;
        for (int16_t j = line_first; (j != EQR_NO_NODE) && (j != stop); j = nodes[j].next){
            w += ((j == line_first) ? 0 : nodes[j].pre) + nodes[j].w;
            if (nodes[j].asc > asc) asc = nodes[j].asc;
            if (nodes[j].desc > desc) desc = nodes[j].desc;
        }
        // first node of the line: no leading gap
        int16_t saved_pre = nodes[line_first].pre;
        nodes[line_first].pre = 0;
        // last screen that still fits in the output: never show an arrow pointing to nothing
        uint8_t continues = (stop != EQR_NO_NODE) && (count + 1 < max_xbms);
        render_line(line_first, stop, w, asc, desc, continues, xbm_out + count * EQR_BYTES_PER_XBM);
        nodes[line_first].pre = saved_pre;
        count++;
        line_first = stop;
    }
    return count;
}
