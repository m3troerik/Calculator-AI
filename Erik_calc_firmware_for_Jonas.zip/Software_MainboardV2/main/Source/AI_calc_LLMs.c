/*

ChatGPT Hardware Hack for calculators: Software V2

© 2026 Jonas Heselschwerdt
Licensed under GPLv3 

LLMs.c: Handles communication with the APIs of AI-Assistants

*/

// Implemented: OpenAI Responses API
// Still missing: Gemini, Claude

// #region Includes

/*
#########################################################################################
##                                                                                     ##
##  Includes                                                                           ##
##                                                                                     ##
#########################################################################################
*/

#include "freertos/FreeRTOS.h"
#include "nvs_flash.h"
#include "nvs.h"
#include "esp_err.h"
#include "esp_log.h"
#include "esp_littlefs.h"
#include <sys/stat.h>
#include <unistd.h>
#include <dirent.h>
#include "string.h"
#include <stdio.h>
#include "cJSON.h"
#include "esp_http_client.h"
#include "esp_crt_bundle.h"

#include "AI_calc_LLMS.h"
#include "AI_calc_UI.h"
#include "AI_calc_camera.h"
#include "AI_calc_eqrender.h"

// #endregion

// #region Generic static variables

/*
#########################################################################################
##                                                                                     ##
##  Generic static variables                                                           ##
##                                                                                     ##
#########################################################################################
*/

static nvs_handle_t api_keys_handle;

static const char base64_LUT[64] = {
    'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z',
    'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z',
    '0','1','2','3','4','5','6','7','8','9','+','/'
};

// For equation rendering
static char equations_buf[MAX_EQS_FOR_RENDERING][MAX_STRLEN_EQS+1];
static char eq_rendering_server[64];
static uint8_t eq_render_server_active;
static nvs_handle_t eq_render_handle;

// #endregion

// #region OpenAI static variables

/*
#########################################################################################
##                                                                                     ##
##   OpenAI static variables                                                           ##
##                                                                                     ##
#########################################################################################
*/

static EventGroupHandle_t openai_events;
static nvs_handle_t responseID_handle;

/*
The instructions below get added to every prompt, I try to avoid OpenAI giving me responses that mess up 
the display rendering this way. This is specifically important for equations.
Equations get rendered on an ext. http server and sent back in XBM format for direct rendering.
The ext. server uses Matplotlib for rendering, which cannot do all formatting specifiers:
*/
static const char openai_instructions[] =   "Always answer the question in the user's LATEST message and the image(s) attached to it. "
                                            "Earlier messages are only context, do not answer them again. "
                                            "If the latest message has no image and no readable question, reply exactly: NO QUESTION RECEIVED. "
                                            "Photos come from a small built-in camera, so some noise, faint stripes or slight blur are normal: "
                                            "ignore them and answer normally whenever the content is recognisable. "
                                            "Never guess, though: only if the text of a question or its answer options that you need is really not readable, "
                                            "reply with PHOTO UNREADABLE - please retake the photo, followed by one short sentence saying what could not be read. "
                                            "Photos without text (objects, scenes, diagrams) are never unreadable just because they contain no question. "
                                            "If you can read everything but are not confident which answer is correct, start your reply with UNSURE: "
                                            "and explain briefly why, instead of presenting a guess as the answer. "
                                            "For every task that involves calculating (math, physics, chemistry, economics, ...) solve it step by step "
                                            "and write the complete solution exactly like in a school notebook. "
                                            "All equations, all intermediate calculations and all intermediate results must be shown, "
                                            "including substituting the given values and the arithmetic, even if a step seems obvious. Never skip or merge steps. "
                                            "Write each notebook line as its own display equation on its own line; one equation must never contain two notebook lines. "
                                            "Above each equation write at most one short line saying what is done in that step, for example: divide both sides by 2. "
                                            "Keep each equation shorter than 150 characters. Do not use \\\\begin, align or line breaks inside an equation. "
                                            "End with a line starting with Answer: followed by the final result. "
                                            "Use only basic ASCII characters. "
                                            "Do not use Unicode or Emojis. "
                                            "LaTex equations can be rendered, but formating is limited. "
                                            "Only use the following formatting specifiers: " 
                                            "\\\\frac, \\\\sqrt, \\\\sin, \\\\cos, \\\\tan, \\\\log, \\\\ln, \\\\exp, "
                                            "\\\\sum, \\\\prod, \\\\int, \\\\lim, \\\\infty, "
                                            "\\\\alpha, \\\\beta, \\\\gamma, \\\\delta, \\\\theta, \\\\lambda, \\\\mu, \\\\pi, \\\\sigma, \\\\phi, \\\\omega, "
                                            "\\\\cdot, \\\\times, \\\\div, \\\\pm, \\\\mp, \\\\le, \\\\ge, \\\\neq, \\\\approx, "
                                            "\\\\hat, \\\\bar, \\\\vec, \\\\dot, "
                                            "^, _. "
                                            "List of things not to use:"
                                            "\\\\boxed, \\\\left, \\\\right"
                                            "Use only display math with \\\\[...\\\\]"
                                            "Do not use Markdown."
                                            "Do not send back images or diagrams/tables.";

static const char* openai_supported_models[] = {
    "gpt-5.5",
    "gpt-5.6",
    "gpt-5.6-terra",
    "gpt-5.6-luna"
};

// #endregion

// #region Generic static function declarations

/*
#########################################################################################
##                                                                                     ##
##  Generic static function declarations                                               ##
##                                                                                     ##
#########################################################################################
*/

static void apikey_nvs_init(void);

static void base64_encode(uint8_t* raw_data, size_t raw_data_lenght, char* dest);

static uint8_t extract_equations_from_string(char* source_string);
static void equation_render_req_json_create(uint8_t found_eqs, char* req_json);
static void equation_render_http_post(char* req_json, ai_model_TypeDef model, uint16_t chatpos);
static void equation_render_local(uint8_t found_eqs, ai_model_TypeDef model, uint16_t chatpos);
static void get_equation_rendering_server(void);

// #endregion

// #region OpenAI static function declarations

/*
#########################################################################################
##                                                                                     ##
##   OpenAI static function declarations                                               ##
##                                                                                     ##
#########################################################################################
*/

// OpenAI chat save logic
static esp_err_t openAI_chat_clear_chatdata(void);
static esp_err_t openAI_chatdata_append_chat(const char* prompt, char* answer, uint16_t* saved_at_pos);
static esp_err_t openAI_chatdata_get_item (char* string_dest, uint16_t chat_pos, uint8_t show_response);

// OpenAI nvs
static void openAI_nvs_init(void);

// OpenAI main task
static void openAI_get_answer_task(void* parameters);

// OpenAI responses API implementation
static esp_err_t json_append(char** buffer,size_t* buffer_size,size_t* position,const char* string);
static esp_err_t openAI_create_request_json(const char* previous_response_id,char** request_json, const ans_task_params* parameters);
static esp_err_t openAI_http_post(const char* request_json,char** response_json);
static esp_err_t openAI_process_response_json(const char* response_json,char* response_id, ans_task_params* parameters);

// #endregion

// #region OpenAI static functions

/*
#########################################################################################
##                                                                                     ##
##  OpenAI static fucntions                                                            ##
##                                                                                     ##
#########################################################################################
*/

static void openAI_nvs_init(void){

    // For openAI related settings and the last responseID
    ESP_ERROR_CHECK(nvs_open("OpenAIAPI", NVS_READWRITE, &responseID_handle));
}

static esp_err_t openAI_chat_clear_chatdata(void){

    // Delete latest response ID and chatdata
    if (nvs_set_str(responseID_handle,"response_ID","") != ESP_OK){
        return ESP_FAIL;
    }
    if (nvs_commit(responseID_handle) != ESP_OK){
        return ESP_FAIL;
    }
    // Clear the entire chat/openai directory
    DIR* dir = opendir("/littlefs/chat/openai");
    if (!dir) {
        return ESP_FAIL;
    }
    struct dirent* entry;
    while ((entry = readdir(dir)) != NULL){
        // Ignore subdirectories
        if (entry->d_type == DT_DIR){
            continue;
        }
        char filepath[300];
        snprintf(filepath,sizeof(filepath),"/littlefs/chat/openai/%s",entry->d_name);
        if (unlink(filepath) != 0) {
            closedir(dir);
            return ESP_FAIL;
        }
        // ESP_LOGI("Deleted","%s",filepath);
    }
    closedir(dir);
    return ESP_OK;
}

static esp_err_t openAI_chatdata_append_chat(const char* prompt, char* answer, uint16_t* saved_at_pos){

    // Adding an interaction with ChatGPT to the chat directory
    if (strlen(answer) > ANSWER_PAGE_LENGTH){
        answer[ANSWER_PAGE_LENGTH] = '\0';
    }
    // First read the chat_pos of the newest chat
    DIR* dir = opendir("/littlefs/chat/openai");
    if (!dir){
        return ESP_FAIL;
    }
    struct dirent* entry;
    int highest_chat_pos = -1;
    while ((entry = readdir(dir)) != NULL){
        if (entry->d_type == DT_DIR)
            // Ignore directories
            continue;
        if (strncmp(entry->d_name,"answer_",7) != 0){
            // Only check answers
            continue;
        }
        // Convert ending of file name to int
        int selected_file_pos = atoi(entry->d_name + 7);
        highest_chat_pos = (selected_file_pos > highest_chat_pos)?selected_file_pos:highest_chat_pos;
    }
    closedir(dir);
    if (highest_chat_pos >= (MAX_CONVERSATION_LENGTH-1)){
        // This situation should be avoided externally in UI.h (no more space for new chat)
        return ESP_FAIL;
    }
    // Save data
    // Assuming the highest_chat_pos can be up to 65536 (is an uint16_t):
    char filename_answer[64];
    char filename_prompt[64];
    snprintf(filename_answer,sizeof(filename_answer),"/littlefs/chat/openai/answer_%d",(highest_chat_pos+1));
    snprintf(filename_prompt,sizeof(filename_prompt),"/littlefs/chat/openai/prompt_%d",(highest_chat_pos+1));
    FILE* prompt_file = fopen(filename_prompt,"wb");
    if (!prompt_file){
        return ESP_FAIL;
    }
    fwrite(prompt,1,(strlen(prompt)+1),prompt_file);
    fclose(prompt_file);
    FILE* answer_file = fopen(filename_answer,"wb");
    if (!answer_file){
        return ESP_FAIL;
    }
    fwrite(answer,1,(strlen(answer)+1),answer_file);
    fclose(answer_file);
    // Successfully saved data at position saved_at_pos
    if (saved_at_pos != NULL){
        *saved_at_pos = highest_chat_pos+1;
    }
    return ESP_OK;
}

static esp_err_t openAI_chatdata_get_item(char* string_dest, uint16_t chat_pos, uint8_t show_response){

    // Loads either a prompt or a response_id from the chat directory
    // This function assumes string_dest has size of at least ANSWER_PAGE_LENGTH+1
    char filepath[64];
    if (show_response){
        snprintf(filepath, sizeof(filepath),"/littlefs/chat/openai/answer_%u", chat_pos);
    }
    else{
        snprintf(filepath, sizeof(filepath),"/littlefs/chat/openai/prompt_%u", chat_pos);
    }
    FILE* file = fopen(filepath, "rb");
    if (!file) {
        return ESP_FAIL;
    }
    fread(string_dest,1,(ANSWER_PAGE_LENGTH+1),file);
    fclose(file);
    return ESP_OK;
}


static esp_err_t json_append(char** buffer,size_t* buffer_size,size_t* position,const char* string){

    // Appends to unformated Json string, allocates more memory if needed
    if (buffer == NULL || *buffer == NULL || buffer_size == NULL || position == NULL || string == NULL){
        return ESP_ERR_INVALID_ARG;
    }
    size_t string_length = strlen(string);
    // +1 for terminating '\0'
    size_t required_size = *position + string_length + 1;
    if (required_size > *buffer_size){
        // Grow exponentially to avoid frequent reallocations
        size_t new_size = *buffer_size;
        while (new_size < required_size){
            new_size *= 2;
            if (new_size >= REQUEST_JSON_MAX_SIZE){
                new_size = REQUEST_JSON_MAX_SIZE; 
                break;
            }
        }
        if (new_size < required_size) {
            return ESP_ERR_NO_MEM;
        }
        char* new_buffer = heap_caps_realloc(*buffer,new_size,MALLOC_CAP_SPIRAM);
        if (new_buffer == NULL){
            return ESP_ERR_NO_MEM;
        }
        *buffer = new_buffer;
        *buffer_size = new_size;
    }
    memcpy(&(*buffer)[*position],string,string_length);
    *position += string_length;
    (*buffer)[*position] = '\0';
    return ESP_OK;
}

static esp_err_t json_append_escaped(char** buffer,size_t* buffer_size,size_t* position,const char* string){

    // Erik: like json_append, but escapes characters that would break the JSON (quotes, backslashes, control chars).
    // Typed prompts can contain " or \ (e.g. LaTeX), which previously produced an invalid request.
    char chunk[64];
    size_t n = 0;
    for (const char* c = string; *c; c++){
        if (n > sizeof(chunk) - 8){
            chunk[n] = '\0';
            esp_err_t r = json_append(buffer,buffer_size,position,chunk);
            if (r != ESP_OK) return r;
            n = 0;
        }
        unsigned char ch = (unsigned char)*c;
        if (ch == '"' || ch == '\\'){ chunk[n++] = '\\'; chunk[n++] = (char)ch; }
        else if (ch == '\n'){ chunk[n++] = '\\'; chunk[n++] = 'n'; }
        else if (ch == '\r'){ chunk[n++] = '\\'; chunk[n++] = 'r'; }
        else if (ch == '\t'){ chunk[n++] = '\\'; chunk[n++] = 't'; }
        else if (ch < 0x20){ n += snprintf(chunk + n, sizeof(chunk) - n, "\\u%04x", ch); }
        else { chunk[n++] = (char)ch; }
    }
    chunk[n] = '\0';
    return json_append(buffer,buffer_size,position,chunk);
}

static esp_err_t openAI_create_request_json(const char* previous_response_id,char** request_json,const ans_task_params* parameters){

    //Creating an unformated JSON string, not using cJson to save RAM when sending Image files:
    if (request_json == NULL || parameters == NULL || parameters->prompt == NULL || parameters->model_version == NULL){
        return ESP_ERR_INVALID_ARG;
    }
    if (parameters->model_version[0] == '\0'){
        return ESP_ERR_INVALID_ARG;
    }
    *request_json = NULL;
    // Small initial buffer
    size_t buffer_size = REQUEST_JSON_INITIAL_SIZE;
    char* json = heap_caps_malloc(buffer_size,MALLOC_CAP_SPIRAM);
    if (json == NULL){
        return ESP_ERR_NO_MEM;
    }
    size_t position = 0;
    esp_err_t ret;
    json[0] = '\0';
    // {
    ret = json_append(&json,&buffer_size,&position,"{");
    if (ret != ESP_OK){
        goto cleanup;
    }
    // "model":"..."
    ret = json_append(&json,&buffer_size,&position,"\"model\":\"");
    if (ret != ESP_OK){
        goto cleanup;
    }
    ret = json_append(&json,&buffer_size,&position,parameters->model_version);
    if (ret != ESP_OK){
        goto cleanup;
    }
    ret = json_append(&json,&buffer_size,&position,"\"");
    if (ret != ESP_OK){
        goto cleanup;
    }
    // ,"instructions":"..."
    ret = json_append(&json,&buffer_size,&position,",\"instructions\":\"");
    if (ret != ESP_OK){
        goto cleanup;
    }
    ret = json_append(&json,&buffer_size,&position,openai_instructions);
    if (ret != ESP_OK){
        goto cleanup;
    }
    ret = json_append(&json,&buffer_size,&position,"\"");
    if (ret != ESP_OK){
        goto cleanup;
    }
    // ,"previous_response_id":"..."
    if (previous_response_id != NULL && previous_response_id[0] != '\0'){
        ret = json_append(&json,&buffer_size,&position,",\"previous_response_id\":\"");
        if (ret != ESP_OK){
            goto cleanup;
        }
        ret = json_append(&json,&buffer_size,&position,previous_response_id);
        if (ret != ESP_OK){
            goto cleanup;
        }
        ret = json_append(&json,&buffer_size,&position,"\"");
        if (ret != ESP_OK){
            goto cleanup;
        }
    }
    // ,"input":[
    ret = json_append(&json,&buffer_size,&position,",\"input\":[");
    if (ret != ESP_OK){
        goto cleanup;
    }
    // {"role":"user","content":[
    ret = json_append(&json,&buffer_size,&position,"{\"role\":\"user\",\"content\":[");
    if (ret != ESP_OK){
        goto cleanup;
    }
    // {"type":"input_text","text":"..."
    ret = json_append(&json,&buffer_size,&position,"{\"type\":\"input_text\",\"text\":\"");
    if (ret != ESP_OK){
        goto cleanup;
    }
    ret = json_append_escaped(&json,&buffer_size,&position,parameters->prompt);
    if (ret != ESP_OK){
        goto cleanup;
    }
    ret = json_append(&json,&buffer_size,&position,"\"}");
    if (ret != ESP_OK){
        goto cleanup;
    }
    // Adiing Image data to JSON
    for (uint8_t i = 0; i < MAX_SAVED_PICTURES; i++){
        if (parameters->picture_paths[i][0] == '\0'){
            continue;
        }
        FILE* file = fopen(parameters->picture_paths[i], "rb");
        if (file == NULL){
            ret = ESP_FAIL;
            goto cleanup;
        }
        ret = json_append(&json, &buffer_size, &position, ",{\"type\":\"input_image\",\"image_url\":\"data:image/jpeg;base64,");
        if (ret != ESP_OK) {
            fclose(file);
            goto cleanup;
        }
        uint8_t raw_buffer[JPEG_READ_BUFFER_SIZE];
        char base64_buffer[BASE64_BUFFER_SIZE];
        size_t bytes_read;
        while ((bytes_read = fread(raw_buffer, 1, sizeof(raw_buffer), file)) > 0) {
            base64_buffer[0] = '\0';
            base64_encode(raw_buffer, bytes_read, base64_buffer);
            ret = json_append(&json, &buffer_size, &position, base64_buffer);
            if (ret != ESP_OK) {
                fclose(file);
                goto cleanup;
            }
        }
        fclose(file);
        ret = json_append(&json, &buffer_size, &position, "\",\"detail\":\"high\"}");   // Erik: full resolution for reading text
        if (ret != ESP_OK) {
            goto cleanup;
        }
    }
    // Close content, user message, input and root object
    ret = json_append(&json,&buffer_size,&position,"]}]}");
    if (ret != ESP_OK){
        goto cleanup;
    }
    *request_json = json;
    return ESP_OK;

cleanup:

    free(json);
    return ret;
}

static esp_err_t openAI_http_event_handler(esp_http_client_event_t* event){

    // For loading OpenAI response Json
    if (event->event_id == HTTP_EVENT_ON_DATA){
        openAI_response_buffer_t* response = (openAI_response_buffer_t*)event->user_data;
        size_t required_size = response->length + event->data_len + 1;
        if (required_size > response->capacity){
            size_t new_capacity = response->capacity * 2;
            while (new_capacity < required_size){
                new_capacity *= 2;
            }
            char* new_data = realloc(response->data,new_capacity);
            if (new_data == NULL) {
                return ESP_ERR_NO_MEM;
            }
            response->data = new_data;
            response->capacity = new_capacity;
        }
        memcpy(response->data + response->length,event->data,event->data_len);
        response->length += event->data_len;
        response->data[response->length] = '\0';
    }
    return ESP_OK;
}

static esp_err_t openAI_http_post(const char* request_json,char** response_json){

    // For sending the Request JSON to OpenAI
    if (request_json == NULL || response_json == NULL){
        return ESP_ERR_INVALID_ARG;
    }
    *response_json = NULL;
    openAI_response_buffer_t response = {
        .data = malloc(4096),
        .length = 0,
        .capacity = 4096
    };
    if (response.data == NULL){
        return ESP_ERR_NO_MEM;
    }
    response.data[0] = '\0';
    esp_err_t ret = ESP_OK;
    // HTTP client configuration
    esp_http_client_config_t config = {
        .url = "https://api.openai.com/v1/responses",
        .method = HTTP_METHOD_POST,
        .timeout_ms = (OPENAI_API_RESPONSE_TIMEOUT * 1000),
        .crt_bundle_attach = esp_crt_bundle_attach,
        .event_handler = openAI_http_event_handler,
        .user_data = &response
    };
    esp_http_client_handle_t client = esp_http_client_init(&config);
    if (client == NULL){
        free(response.data);
        return ESP_FAIL;
    }
    // HTTP headers
    // Get API key from nvs
    char API_key[API_KEY_MAX_LENGTH+1] = {0};
    size_t length = sizeof(API_key);
    ret = nvs_get_str(api_keys_handle,"openai",API_key,&length);
    if (ret != ESP_OK){
        goto cleanup;
    }
    ret = esp_http_client_set_header(client,"Content-Type","application/json");
    if (ret != ESP_OK){
        goto cleanup;
    }
    char auth_header[API_KEY_MAX_LENGTH+8];
    snprintf(auth_header,sizeof(auth_header),"Bearer %s",API_key);
    // ESP_LOGI("API KEY:","|%s|",auth_header);
    ret = esp_http_client_set_header(client,"Authorization",auth_header);
    if (ret != ESP_OK){
        goto cleanup;
    }
    // Request body
    ret = esp_http_client_set_post_field(client,request_json,strlen(request_json));
    if (ret != ESP_OK){
        goto cleanup;
    }
    // Perform request
    ret = esp_http_client_perform(client);
    if (ret != ESP_OK){
        ESP_LOGE("OpenAI","HTTP POST failed: %s",esp_err_to_name(ret));
        goto cleanup;
    }
    // Response
    if (response.length == 0){
        ESP_LOGE("OpenAI", "Response body is empty");
        ret = ESP_FAIL;
        goto cleanup;
    }
    *response_json = response.data;
    response.data = NULL;
    // ESP_LOGI("OpenAI","Received %u bytes",(unsigned)response.length);
    // HTTP status
    int status_code = esp_http_client_get_status_code(client);
    if (status_code < 200 || status_code >= 300){
        ESP_LOGE("OpenAI","Received Status code: %d",status_code);
        ret = ESP_FAIL;
        goto cleanup;
    }

cleanup:
    free(response.data);
    esp_http_client_cleanup(client);
    return ret;
}

static esp_err_t openAI_process_response_json(const char* response_json, char* response_id, ans_task_params* parameters){

    // Parses received JSON string (using cJson)
    if (response_json == NULL || response_id == NULL || parameters == NULL || parameters->answer == NULL){
        return ESP_ERR_INVALID_ARG;
    }
    cJSON* root = cJSON_Parse(response_json);
    if (root == NULL) {
        return ESP_ERR_INVALID_RESPONSE;
    }
    esp_err_t ret = ESP_FAIL;
    // Response ID
    cJSON* id = cJSON_GetObjectItemCaseSensitive(root, "id");
    if (!cJSON_IsString(id) || id->valuestring == NULL) {
        goto cleanup;
    }
    strcpy(response_id, id->valuestring);
    // output
    cJSON* output = cJSON_GetObjectItemCaseSensitive(root, "output");
    if (!cJSON_IsArray(output)){
        goto cleanup;
    }
    // Search output items
    cJSON* output_item = NULL;
    cJSON_ArrayForEach(output_item, output){
        cJSON* type = cJSON_GetObjectItemCaseSensitive(output_item, "type");
        if (!cJSON_IsString(type) || strcmp(type->valuestring, "message") != 0) {
            continue;
        }
        cJSON* content = cJSON_GetObjectItemCaseSensitive(output_item, "content");
        if (!cJSON_IsArray(content)) {
            continue;
        }
        cJSON* content_item = NULL;
        cJSON_ArrayForEach(content_item, content) {
            cJSON* content_type = cJSON_GetObjectItemCaseSensitive(content_item, "type");
            if (!cJSON_IsString(content_type) || strcmp(content_type->valuestring, "output_text") != 0) {
                continue;
            }
            cJSON* text =
                cJSON_GetObjectItemCaseSensitive(content_item, "text");
            if (!cJSON_IsString(text) || text->valuestring == NULL) {
                continue;
            }
            strncpy(parameters->answer,text->valuestring,ANSWER_PAGE_LENGTH);
            // Always terminate at ANSWER_PAGE_LENGTH
            parameters->answer[ANSWER_PAGE_LENGTH] = '\0';
            ret = ESP_OK;
            goto cleanup;
        }
    }

cleanup:

    cJSON_Delete(root);
    return ret;
    return ESP_OK;
}

static void openAI_get_answer_task(void* parameters){

    ans_task_params* params = (ans_task_params*) parameters;
    char* request_json = NULL;
    if (params->start_new_chat){
        // Delete chatdata
        openAI_chat_clear_chatdata();
        // Create request Json
        if (openAI_create_request_json("",&request_json,params) != ESP_OK){
            // Error creating request JSON
            strcpy(params->answer,"JSON CREATE ERROR");
            openAI_chatdata_append_chat(params->prompt,params->answer,NULL);
            nvs_set_str(responseID_handle,"response_ID","");
            nvs_commit(responseID_handle);
            xEventGroupSetBits(openai_events, OPENAI_DONE_BIT);
            vTaskDelete(NULL);
        }
        // ESP_LOGI("JSON Request","\n %s",request_json);
    }
    else{
        // Get Last Response ID
        char previous_response_id[128] = {0};
        size_t length = sizeof(previous_response_id);
        if (nvs_get_str(responseID_handle,"response_ID",previous_response_id,&length) != ESP_OK){
            // ESP_LOGI("OpenAI","No previous response ID available, starting new chat");
            strcpy(previous_response_id,"");
        }
        // Create request Json
        if (openAI_create_request_json(previous_response_id,&request_json,parameters) != ESP_OK){
            // Error creating request JSON
            strcpy(params->answer,"JSON CREATE ERROR");
            openAI_chatdata_append_chat(params->prompt,params->answer,NULL);
            nvs_set_str(responseID_handle,"response_ID","");
            nvs_commit(responseID_handle);
            xEventGroupSetBits(openai_events, OPENAI_DONE_BIT);
            vTaskDelete(NULL);
        }
        // ESP_LOGI("JSON Request","\n %s",request_json);
    }
    // Erik: start from an empty answer, so an old answer can never be shown again by accident
    params->answer[0] = '\0';
    // Http POST Json
    char* response_json = NULL;
    if (openAI_http_post(request_json,&response_json) != ESP_OK){
        // Error posting request JSOn via Http
        // Erik: show OpenAI's own error message if there is one (e.g. invalid key, no credit, bad image)
        snprintf(params->answer,ANSWER_PAGE_LENGTH+1,"HTTP POST ERROR");
        if (response_json != NULL){
            cJSON* err_root = cJSON_Parse(response_json);
            cJSON* err = err_root ? cJSON_GetObjectItemCaseSensitive(err_root,"error") : NULL;
            cJSON* msg = err ? cJSON_GetObjectItemCaseSensitive(err,"message") : NULL;
            if (cJSON_IsString(msg) && msg->valuestring != NULL){
                snprintf(params->answer,ANSWER_PAGE_LENGTH+1,"HTTP POST ERROR: %s",msg->valuestring);
            }
            cJSON_Delete(err_root);
            free(response_json);
        }
        openAI_chatdata_append_chat(params->prompt,params->answer,NULL);
        nvs_set_str(responseID_handle,"response_ID","");
        nvs_commit(responseID_handle);
        free(request_json);
        xEventGroupSetBits(openai_events, OPENAI_DONE_BIT);
        vTaskDelete(NULL);
    }
    free(request_json);
    // ESP_LOGI("JSON RESPONSE", "\n %s", response_json);
    // Process response Json
    char new_latest_response_id[128] = {0};
    if (openAI_process_response_json(response_json,new_latest_response_id,params) != ESP_OK){
        // Erik: previously the return value was ignored -> the answer buffer kept the PREVIOUS answer
        // (off-topic answers) and an uninitialized response id was stored.
        ESP_LOGE("OpenAI","Could not read answer from response: %.300s", response_json ? response_json : "(null)");
        snprintf(params->answer,ANSWER_PAGE_LENGTH+1,"NO ANSWER IN RESPONSE (status not completed or parse error). Try again.");
        new_latest_response_id[0] = '\0';
    }
    free(response_json);
    // Append text exchange to chatdata
    // Erik: extract equations first, the saved answer text then contains [n] markers instead of LaTeX
    uint8_t equation_count = extract_equations_from_string(params->answer);
    uint16_t saved_at_chatpos = 0;
    esp_err_t chat_saved = openAI_chatdata_append_chat(params->prompt,params->answer,&saved_at_chatpos);
    // Equation rendering
    if (chat_saved != ESP_OK){
        // Erik: chat item not saved -> nowhere to attach equation images
    }
    else if (!eq_render_server_active){
        // Erik: no render server configured -> render the equations on the calculator itself
        equation_render_local(equation_count,AI_MODEL_OPENAI,saved_at_chatpos);
    }
    else{
        // Get equation renders if there are any (@ saved_at_chatpos)
        char* eq_render_req_json = malloc(MAX_EQS_FOR_RENDERING*MAX_STRLEN_EQS*4/3);   // *4/3 to give some room for formatting-overhead
        if(eq_render_req_json != NULL){
            equation_render_req_json_create(equation_count,eq_render_req_json);
            equation_render_http_post(eq_render_req_json,AI_MODEL_OPENAI,saved_at_chatpos);
            free(eq_render_req_json);
        }
        // Erik: server not reachable / failed -> fall back to rendering on the calculator
        char first_xbm[96];
        snprintf(first_xbm,sizeof(first_xbm),"/littlefs/chat/openai/equation_%u_0",saved_at_chatpos);
        struct stat st;
        if ((equation_count > 0) && (stat(first_xbm,&st) != 0)){
            equation_render_local(equation_count,AI_MODEL_OPENAI,saved_at_chatpos);
        }
    }
    // Save latest Response ID
    nvs_set_str(responseID_handle,"response_ID",new_latest_response_id);
    nvs_commit(responseID_handle);
    // End Task
    xEventGroupSetBits(openai_events, OPENAI_DONE_BIT);
    vTaskDelete(NULL);
}

// #endregion

// #region Generic static functions

/*
#########################################################################################
##                                                                                     ##
##   Generic static functions                                                          ##
##                                                                                     ##
#########################################################################################
*/

static void apikey_nvs_init(void){

    ESP_ERROR_CHECK(nvs_open("api_keys", NVS_READWRITE, &api_keys_handle));
}

static void base64_encode(uint8_t* raw_data, size_t raw_data_length, char* dest){

    /*
    To base64 encode big JPGs (e.g. 0.8MiB): Read small buffers (e.g. raw_data_length = 1200 Bytes) and convert them
    into separate base64 strings, buffersize (in bytes) has to be divisible by 3.
    The last buffer (and only this one) of the JPG data can be not divisible by 3
    Images sent to OpenAI API must be Base64 encoded
    */
    uint8_t padding_leftover = (uint8_t)(raw_data_length % 3);
    size_t encoding_steps = (raw_data_length / 3);
    if (padding_leftover){
        encoding_steps++;
    }
    for (size_t i=0; i< encoding_steps; i++){
        if ((!padding_leftover) || (i!=encoding_steps-1)){
            // Do not need padding
            uint32_t encoding_buf = 0;
            char string_buf[5];
            encoding_buf += (uint32_t)((raw_data[i*3])<<16);
            encoding_buf += (uint32_t)((raw_data[(i*3)+1])<<8);
            encoding_buf += raw_data[(i*3)+2];
            string_buf[0] = base64_LUT[(uint8_t)((encoding_buf>>18)&0b00111111)];
            string_buf[1] = base64_LUT[(uint8_t)((encoding_buf>>12)&0b00111111)];
            string_buf[2] = base64_LUT[(uint8_t)((encoding_buf>>6)&0b00111111)];
            string_buf[3] = base64_LUT[(uint8_t)((encoding_buf)&0b00111111)];
            string_buf[4] = '\0';
            strcat(dest,string_buf);
        }
        else if ((padding_leftover == 1) && (i==(encoding_steps-1))){
            // Padding needed
            uint16_t encoding_buf = 0;
            char string_buf[5];
            encoding_buf += (uint16_t)(raw_data[i*3] << 4);
            string_buf[0] = base64_LUT[(uint8_t)((encoding_buf>>6) & 0b00111111)];
            string_buf[1] = base64_LUT[(uint8_t)(encoding_buf & 0b00111111)];
            string_buf[2] = '=';
            string_buf[3] = '=';
            string_buf[4] = '\0';
            strcat(dest,string_buf);
        }
        else{
            // Padding needed
            uint32_t encoding_buf = 0;
            char string_buf[5];
            encoding_buf += (uint32_t)(raw_data[i*3] << 10);
            encoding_buf += (uint32_t)((raw_data[(i*3)+1]) << 2);
            string_buf[0] = base64_LUT[(uint8_t)((encoding_buf>>12) & 0b00111111)];
            string_buf[1] = base64_LUT[(uint8_t)((encoding_buf>>6) & 0b00111111)];
            string_buf[2] = base64_LUT[(uint8_t)(encoding_buf & 0b00111111)];
            string_buf[3] = '=';
            string_buf[4] = '\0';
            strcat(dest,string_buf);
        }
    }
}

static uint8_t extract_equations_from_string(char* source_string){

    /*
    Analyses the source_string, latex/mathtext formated equations will land in
    static char equations_buf[MAX_EQS_FOR_RENDERING][MAX_STRLEN_EQS+1]
    Retruns: amount of found equations
    Erik: also rewrites source_string for the 20x4 main display:
    - every extracted \[...\] is replaced by its step number "[n]" (same n as "n/N" on the side display)
    - a line break starts a new display row (padded with spaces), empty lines are dropped
    Equations that are too long or beyond MAX_EQS_FOR_RENDERING stay as text and get no number.
    */
    static char out[ANSWER_PAGE_LENGTH + 1];
    size_t o = 0;
    uint8_t found_eqs = 0;
    const char* p = source_string;
    for (uint8_t i=0; i<MAX_EQS_FOR_RENDERING; i++){
        equations_buf[i][0] = '\0';
    }
    while ((*p != '\0') && (o < ANSWER_PAGE_LENGTH)){
        if ((p[0] == '\\') && (p[1] == '[')){
            const char* end = strstr(p + 2, "\\]");
            if (end != NULL){
                const char* b = p + 2;
                const char* e = end;
                while ((b < e) && ((*b == '\n') || (*b == '\r') || (*b == ' '))) b++;
                while ((e > b) && ((e[-1] == '\n') || (e[-1] == '\r') || (e[-1] == ' '))) e--;
                size_t len = (size_t)(e - b);
                if ((len > 0) && (len <= MAX_STRLEN_EQS) && (found_eqs < MAX_EQS_FOR_RENDERING)){
                    memcpy(equations_buf[found_eqs], b, len);
                    equations_buf[found_eqs][len] = '\0';
                    found_eqs++;
                    char marker[8];
                    int ml = snprintf(marker, sizeof(marker), "[%u]", found_eqs);
                    if ((o > 0) && (out[o-1] != ' ') && ((o % MAIN_DISPLAY_COLUMNS) != 0) && (o < ANSWER_PAGE_LENGTH)){
                        out[o++] = ' ';
                    }
                    for (int k = 0; (k < ml) && (o < ANSWER_PAGE_LENGTH); k++){
                        out[o++] = marker[k];
                    }
                    p = end + 2;
                    continue;
                }
                // too long / too many: keep it as text
            }
        }
        if (*p == '\r'){
            p++;
            continue;
        }
        if (*p == '\n'){
            // next display row
            while (((o % MAIN_DISPLAY_COLUMNS) != 0) && (o < ANSWER_PAGE_LENGTH)){
                out[o++] = ' ';
            }
            p++;
            continue;
        }
        out[o++] = *p++;
    }
    out[o] = '\0';
    strcpy(source_string, out);
    return found_eqs;
}

static void equation_render_req_json_create(uint8_t found_eqs, char* req_json){

    // Creating a Request JSON with the equations that need to be displayed
    char* ptr = req_json;
    ptr += sprintf(ptr,
                   "{\"width\":%u,\"height\":%u,\"max_xbms\":%u,\"equations\":[",
                   XBMS_WIDTH,
                   XBMS_HEIGHT,
                   MAX_XBMS_PER_ANS);
    for (uint8_t i = 0; i < found_eqs; i++){
        ptr += sprintf(ptr, "\"%s\"", equations_buf[i]);
        if (i < found_eqs - 1){
            ptr += sprintf(ptr, ",");
        }
    }
    sprintf(ptr, "]}");
}

#if BYTES_PER_XBM != EQR_BYTES_PER_XBM
#error "eqrender bitmap size must match the XBM size used for the side display"
#endif

static void equation_render_local(uint8_t found_eqs, ai_model_TypeDef model, uint16_t chatpos){

    // Erik: renders equations_buf[] on the ESP32 (AI_calc_eqrender.c) and saves them exactly like the
    // render server's XBMs (equation_<chatpos>_<n>), so the existing side display code shows them.
    // Long equations become several XBMs (one line each), browsed with the bracket keys.
    const char* dir;
    switch (model){
        case AI_MODEL_GEMINI: dir = "gemini"; break;
        case AI_MODEL_CLAUDE: dir = "claude"; break;
        case AI_MODEL_OPENAI:
        default: dir = "openai"; break;
    }
    static uint8_t xbms[4 * BYTES_PER_XBM];
    uint8_t step_of_xbm[MAX_XBMS_PER_ANS + 1];     // [0] = number of steps, [1+n] = step number of XBM n
    uint16_t saved = 0;
    step_of_xbm[0] = found_eqs;
    for (uint8_t i = 0; (i < found_eqs) && (saved < MAX_XBMS_PER_ANS); i++){
        uint8_t count = eqr_render_to_xbms(equations_buf[i], xbms, 4);
        for (uint8_t k = 0; (k < count) && (saved < MAX_XBMS_PER_ANS); k++){
            step_of_xbm[1 + saved] = i + 1;
            char filename[96];
            snprintf(filename,sizeof(filename),"/littlefs/chat/%s/equation_%u_%u",dir,chatpos,saved);
            FILE* file = fopen(filename,"wb");
            if (file == NULL){
                ESP_LOGE("EquationRendering","Failed to open %s",filename);
                return;
            }
            fwrite(&xbms[k * BYTES_PER_XBM],1,BYTES_PER_XBM,file);
            fclose(file);
            saved++;
        }
    }
    // step numbers for the "n/N" label on the side display
    char metaname[96];
    snprintf(metaname,sizeof(metaname),"/littlefs/chat/%s/eqmeta_%u",dir,chatpos);
    FILE* meta = fopen(metaname,"wb");
    if (meta != NULL){
        fwrite(step_of_xbm,1,(size_t)saved + 1,meta);
        fclose(meta);
    }
    ESP_LOGI("EquationRendering","Rendered %u equation image(s) on device",saved);
}

static void equation_render_http_post(char* req_json, ai_model_TypeDef model, uint16_t chatpos){

    // Get renderings of eqautions from server in local network
    // Get filename where to save renderings (ai model directory)
    char filename_start[128];
    switch(model){
        case AI_MODEL_OPENAI:
            sprintf(filename_start,"/littlefs/chat/openai/equation_%u_",chatpos);
            break;
        case AI_MODEL_GEMINI:
            sprintf(filename_start,"/littlefs/chat/gemini/equation_%u_",chatpos);
            break;
        case AI_MODEL_CLAUDE:
            sprintf(filename_start,"/littlefs/chat/claude/equation_%u_",chatpos);
            break;
    }
    // HTTP configuration
    if (eq_rendering_server[0] == '\0'){
        ESP_LOGE("EquationRendering","No Server IP provided");
        return;
    }
    char url_buf[128];
    snprintf(url_buf,sizeof(url_buf),"http://%s:8080/render",eq_rendering_server);
    esp_http_client_config_t config = {
        .url = url_buf,
        .method = HTTP_METHOD_POST,
        .timeout_ms = (EQ_RENDER_RESPONSE_TIMEOUT * 1000),
    };
    esp_http_client_handle_t client = esp_http_client_init(&config);
    if (client == NULL){
        ESP_LOGE("EquationRendering","HTTP error");
        return;
    }
    esp_http_client_set_header(client, "Content-Type", "application/json");
    esp_http_client_set_post_field(client, req_json, strlen(req_json));
    esp_err_t err = esp_http_client_open(client, strlen(req_json));
    if (err != ESP_OK){
        ESP_LOGE("EquationRendering", "HTTP open failed: %s", esp_err_to_name(err));
        esp_http_client_cleanup(client);
        return;
    }
    // Send POST request
    int written = esp_http_client_write(client, req_json, strlen(req_json));
    if (written < 0){
        ESP_LOGE("EquationRendering", "Failed to send POST data");
        esp_http_client_close(client);
        esp_http_client_cleanup(client);
        return;
    }
    // Read HTTP response headers, check if the server messed something up:
    int content_length = esp_http_client_fetch_headers(client);
    // ESP_LOGI("EquationRendering", "Content length: %d", content_length);
    if (content_length <= 0){
        ESP_LOGE("EquationRendering", "Invalid content length");
        esp_http_client_close(client);
        esp_http_client_cleanup(client);
        return;
    }
    if (content_length % BYTES_PER_XBM != 0){
        ESP_LOGE("EquationRendering","Invalid XBM stream length: %d",content_length);
        esp_http_client_close(client);
        esp_http_client_cleanup(client);
        return;
    }
    uint16_t xbm_count = content_length / BYTES_PER_XBM;
    if (xbm_count > MAX_XBMS_PER_ANS){
        ESP_LOGE("EquationRendering","Server returned too many XBMs: %u",xbm_count);
        esp_http_client_close(client);
        esp_http_client_cleanup(client);
        return;
    }
    // ESP_LOGI("EquationRendering", "Receiving %u XBMs", xbm_count);
    // Start reading XBMs and saving them
    uint8_t buffer[BYTES_PER_XBM];
    for (uint16_t i = 0; i < xbm_count; i++){
        // Create filename
        char filename[144];
        snprintf(filename,sizeof(filename),"%s%u",filename_start,i);
        FILE *file = fopen(filename, "wb");
        if (file == NULL) {
            ESP_LOGE("EquationRendering","Failed to open %s",filename);
            break;
        }
        // Receive exactly one XBM (streaming response)
        size_t received = 0;
        while (received < BYTES_PER_XBM) {
            int ret = esp_http_client_read(client,(char *)&buffer[received],BYTES_PER_XBM - received);
            if (ret < 0) {
                ESP_LOGE("EquationRendering", "HTTP read failed");
                break;
            }
            if (ret == 0) {
                ESP_LOGE("EquationRendering","HTTP stream ended unexpectedly");
                break;
            }
            received += ret;
        }
        if (received != BYTES_PER_XBM) {
            fclose(file);
            break;
        }
        // Save XBM
        size_t written_file = fwrite(buffer,1,BYTES_PER_XBM,file);
        fclose(file);
        if (written_file != BYTES_PER_XBM) {
            ESP_LOGE("EquationRendering","Failed to write complete XBM");
            break;
        }
        // ESP_LOGI("EquationRendering","Received XBM %u/%u",i + 1,xbm_count);
    }
}

static void get_equation_rendering_server(void){

    // During initialization
    ESP_ERROR_CHECK(nvs_open("eq_render",NVS_READWRITE,&eq_render_handle));
    size_t len = sizeof(eq_rendering_server);
    if (nvs_get_str(eq_render_handle,"ipv4_eq_render",eq_rendering_server,&len) != ESP_OK){
        // No server saved
        strcpy(eq_rendering_server,"");
    }
    if (nvs_get_u8(eq_render_handle,"eq_render_act",&eq_render_server_active) != ESP_OK){
        eq_render_server_active = 0;
    }
}

// #endregion

// #region Generic extern functions

/*
#########################################################################################
##                                                                                     ##
##   Generic extern functions                                                          ##
##                                                                                     ##
#########################################################################################
*/

void llms_init(void){

    apikey_nvs_init();
    openAI_nvs_init();
    // Load server IP for equation rendering
    get_equation_rendering_server();
    // Each model gets their own directory for chat data
    mkdir("/littlefs/chat/openai",0755);
    mkdir("/littlefs/chat/claude",0755);
    mkdir("/littlefs/chat/gemini",0755);
}

esp_err_t save_API_Key(ai_model_TypeDef ai_model, char* api_key){

    if (ai_model == AI_MODEL_OPENAI){
        if(nvs_set_str(api_keys_handle,"openai",api_key)!=ESP_OK){
            return ESP_FAIL;
        }
    }
    else if (ai_model == AI_MODEL_GEMINI){
        if(nvs_set_str(api_keys_handle,"gemini",api_key)!=ESP_OK){
            return ESP_FAIL;
        }
    }
    else if (ai_model == AI_MODEL_CLAUDE){
        if(nvs_set_str(api_keys_handle,"claude",api_key)!=ESP_OK){
            return ESP_FAIL;
        }
    }
    if(nvs_commit(api_keys_handle)!=ESP_OK){
        return ESP_FAIL;
    }
    return ESP_OK;
}

void set_equation_render_server(char* server_ip, size_t ip_len, uint8_t active){

    // Set IPv4 of host pc for equation rendering in local netowrk, 
    eq_render_server_active = (active!=0);
    nvs_set_u8(eq_render_handle,"eq_render_act",eq_render_server_active);
    if ((server_ip != NULL) && (ip_len <= sizeof(eq_rendering_server))){
        strcpy(eq_rendering_server,server_ip);
        nvs_set_str(eq_render_handle,"ipv4_eq_render",eq_rendering_server);
    }
}

uint8_t get_eq_render_server_state(void){

    // Getter function for UI
    return eq_render_server_active;
}

esp_err_t get_eq_step_label(ai_model_TypeDef model, uint16_t chatpos, uint8_t equation_index, char* label, size_t label_size){

    // Erik: "n/N" = notebook line (step) of the XBM at equation_index, from equation_render_local()
    if ((label == NULL) || (label_size < 8)){
        return ESP_FAIL;
    }
    const char* dir = (model == AI_MODEL_GEMINI) ? "gemini" : ((model == AI_MODEL_CLAUDE) ? "claude" : "openai");
    char filename[96];
    snprintf(filename,sizeof(filename),"/littlefs/chat/%s/eqmeta_%u",dir,chatpos);
    FILE* f = fopen(filename,"rb");
    if (f == NULL){
        return ESP_FAIL;
    }
    uint8_t meta[MAX_XBMS_PER_ANS + 1];
    size_t n = fread(meta,1,sizeof(meta),f);
    fclose(f);
    if ((n < 2) || ((size_t)equation_index + 1 >= n) || (meta[0] == 0)){
        return ESP_FAIL;
    }
    snprintf(label,label_size,"%u/%u",meta[1 + equation_index],meta[0]);
    return ESP_OK;
}

esp_err_t get_eq_rendering(ai_model_TypeDef model, uint16_t chatpos, uint8_t equation_index, uint8_t* buf){

    // Load bitmap into buf, return ESP_FAIL if non existent
    char filename[128];
    switch (model){
        case AI_MODEL_OPENAI:
            sprintf(filename,"/littlefs/chat/openai/equation_%u_%u",chatpos,equation_index);
            break;
        case AI_MODEL_GEMINI:
            sprintf(filename,"/littlefs/chat/gemini/equation_%u_%u",chatpos,equation_index);
            break;
        case AI_MODEL_CLAUDE:
            sprintf(filename,"/littlefs/chat/claude/equation_%u_%u",chatpos,equation_index);
            break;
    }
    FILE* f = fopen(filename,"rb");
    if (f == NULL){
        // ESP_LOGI("EQRender","Failed to load XBM @ %s",filename);
        return ESP_FAIL;
    }
    fread(buf,1,BYTES_PER_XBM,f);
    // ESP_LOGI("EQRender","Loaded XBM @ %s",filename);
    fclose(f);
    return ESP_OK;
}

// #endregion

// #region OpenAI extern functions

/*
#########################################################################################
##                                                                                     ##
##  OpenAI extern functions                                                            ##
##                                                                                     ##
#########################################################################################
*/

void start_openai_conversation(char* new_prompt, char* ans_dest, size_t ans_dest_size, char (*pic_paths)[64], char* model_ver){

    /*
    Call when starting a new chat
    Caution: This function is RAM hungry, needs REQUEST_JSON_MAX_SIZE bytes available in PSRAM (in worst case),
    if pictures are appended as littlefs paths
    */
    if (ans_dest_size < (size_t)(ANSWER_PAGE_LENGTH+1)){
        ESP_LOGE("OpenAI","Ans buffer size has to be at least ANSWER_PAGE_LENGTH");
        return;
    }
    uint8_t model_ver_valid = 0;
    for (size_t i=0; i<(sizeof(openai_supported_models)/sizeof(openai_supported_models[0])); i++){
        if (strcmp(model_ver,openai_supported_models[i]) == 0){
            model_ver_valid = 1;
            break;
        }
    }
    if (!model_ver_valid){
        ESP_LOGE("OpenAI","Invalid model name");
        return;
    }
    if (!openai_events){
        openai_events = xEventGroupCreate();
    }
    xEventGroupClearBits(openai_events,OPENAI_DONE_BIT);
    ans_task_params parameters = {
        .prompt = new_prompt,
        .answer = ans_dest,
        .answer_length = ans_dest_size,
        .start_new_chat = 1,
        .picture_paths = pic_paths,
        .model_version = model_ver
    };
    // It is okay to give the address of parameters to xtaskcreate since we wait for the task to finish
    // with xeventgroupwaitbits (parameters only exists within stack)
    xTaskCreate(openAI_get_answer_task, "openAI",16384,&parameters,3,NULL);
    xEventGroupWaitBits(openai_events,OPENAI_DONE_BIT,pdFALSE,pdTRUE,portMAX_DELAY);
}

void get_openai_response(char* new_prompt, char* ans_dest, size_t ans_dest_size, char (*pic_paths)[64], char* model_ver){

    /*
    Call when trying to get a response in the previous chat
    Caution: This function is RAM hungry, needs REQUEST_JSON_MAX_SIZE bytes in PSRAM (in worst case),
    if pictures are appended as littlefs paths
    */
    if (ans_dest_size < (size_t)(ANSWER_PAGE_LENGTH+1)){
        ESP_LOGE("OpenAI","Ans buffer size has to be at least ANSWER_PAGE_LENGTH");
        return;
    }
    uint8_t model_ver_valid = 0;
    for (size_t i=0; i<(sizeof(openai_supported_models)/sizeof(openai_supported_models[0])); i++){
        if (strcmp(model_ver,openai_supported_models[i]) == 0){
            model_ver_valid = 1;
            break;
        }
    }
    if (!model_ver_valid){
        ESP_LOGE("OpenAI","Invalid model name");
        return;
    }
    if (!openai_events){
        openai_events = xEventGroupCreate();
    }
    xEventGroupClearBits(openai_events,OPENAI_DONE_BIT);
    ans_task_params parameters = {
        .prompt = new_prompt,
        .answer = ans_dest,
        .answer_length = ans_dest_size,
        .start_new_chat = 0,
        .picture_paths = pic_paths,
        .model_version = model_ver
    };
    // It is okay to give the address of parameters to xtaskcreate since we wait for the task to finish
    // with xeventgroupwaitbits (parameters only exists within stack)
    xTaskCreate(openAI_get_answer_task, "openAI",16384,&parameters,3,NULL);
    xEventGroupWaitBits(openai_events,OPENAI_DONE_BIT,pdFALSE,pdTRUE,portMAX_DELAY);
}

void load_prev_openai_response(uint16_t chat_position, char* ans_dest, size_t ans_dest_size){

    // Load the response ID from littlefs
    if (ans_dest_size < (size_t)(ANSWER_PAGE_LENGTH+1)){
        ESP_LOGE("OpenAI Chat","Ans buffer size has to be at least ANSWER_PAGE_LENGTH");
        return;
    }
    if (chat_position >= MAX_CONVERSATION_LENGTH){
        ESP_LOGE("OpenAI Chat","Invalid Chat pos");
    }
    openAI_chatdata_get_item(ans_dest,chat_position,1);
}

void load_prev_openai_prompt(uint16_t chat_position, char* prompt_dest, size_t prompt_dest_size){

    // Load prompt from littlefs
    if (prompt_dest_size < (size_t)(SCRIBBLE_PAGE_LENGTH+1)){
        ESP_LOGE("OpenAI Chat","Prompt buffer size has to be at least SCRIBBLE_PAGE_LENGTH");
        return;
    }
    if (chat_position >= MAX_CONVERSATION_LENGTH){
        ESP_LOGE("OpenAI Chat","Invalid Chat pos");
    }
    openAI_chatdata_get_item(prompt_dest,chat_position,0);
}

uint16_t openai_chat_dir_text_exchanges(void)
{
    char buf[SCRIBBLE_PAGE_LENGTH + 1];
    for (int16_t i = MAX_CONVERSATION_LENGTH - 1; i >= 0; i--) {
        if (openAI_chatdata_get_item(buf, i, 0) == ESP_OK){
            return (uint16_t)(i + 1);
        }
    }
    return 0;
}

void openai_delete_chats(void){

    // To manually clear chatdata in UI, ignores return value
    openAI_chat_clear_chatdata();
}

// #endregion