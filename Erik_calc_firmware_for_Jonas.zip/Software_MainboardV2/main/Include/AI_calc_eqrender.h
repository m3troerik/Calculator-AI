/*
ChatGPT Hardware Hack for calculators: Software V2
eqrender: renders the LaTeX subset requested by the firmware's OpenAI instructions
directly on the ESP32 into XBM bitmaps (no PC / render server needed).

Supported: \frac \sqrt (incl. \sqrt[n]) ^ _ (with {..} or single token), \sin \cos \tan \log \ln \exp \lim,
\sum \prod \int (with limits), Greek letters, \cdot \times \div \pm \mp \le \ge \neq \approx \infty,
\hat \bar \vec \dot, \left \right (ignored, brackets grow automatically), \, \; \quad \text{}.
Unknown commands are shown as their name. Never crashes on bad input (bounded pools and recursion).

Added by Erik (2026). Licensed under GPLv3 like the rest of the software.
*/

#ifndef AI_CALC_EQRENDER_H
#define AI_CALC_EQRENDER_H

#include <stdint.h>

#define EQR_WIDTH 128
#define EQR_HEIGHT 40
#define EQR_BYTES_PER_XBM (EQR_WIDTH * EQR_HEIGHT / 8)

/*
Renders one LaTeX equation (without the surrounding \[ \]) into up to max_xbms XBM bitmaps
of EQR_WIDTH x EQR_HEIGHT pixels (XBM format: rows of 16 bytes, LSB = leftmost pixel).
Long equations are split into several bitmaps (one line each).
xbm_out must hold max_xbms * EQR_BYTES_PER_XBM bytes.
Returns the number of bitmaps written (0 on failure / empty input).
Not thread safe (uses static buffers) - call from one task only.
*/
uint8_t eqr_render_to_xbms(const char* latex, uint8_t* xbm_out, uint8_t max_xbms);

#endif
