/*

ChatGPT Hardware Hack for calculators: Software V2

© 2026 Jonas Heselschwerdt
Licensed under GPLv3

provisioning.h: Local setup web server

*/

#ifndef PROVISIONING_H
#define PROVISIONING_H

#include "esp_err.h"

esp_err_t provisioning_server_start(void);
void provisioning_server_stop(void);

#endif
