# Erik's changes to ChatGPT-mod-for-calculators (Software V2)

Based on upstream commit `a208139` (SW v2.0.1), Mainboard V2.0.3, OV5640.
Built with ESP-IDF 5.5.6 and running on our calculator.
`changes_vs_upstream_a208139.patch` contains every change against your repo (without u8g2 `csrc`, managed components and sdkconfig).

## New features
- **Equation rendering on the ESP32** (`AI_calc_eqrender.c/.h`, new): renders the LaTeX subset from the OpenAI instructions with U8g2 into the same 128×40 XBMs as the Python server, saved as `equation_<chatpos>_<n>`, so the existing side-display code shows them. Fractions, roots (also `\sqrt[n]`), powers/subscripts, `\sum \prod \int` with limits, `\lim`, functions, Greek letters, `\pm \cdot \times \div \le \ge \neq \approx \infty \to`, accents, brackets that grow around fractions, `\left/\right`, `\text`. Picks the largest font that fits (9x15 → 5x7); equations that are too wide are split over several screens.
  - It uses its own off-screen U8g2 instance, never the real display buffer.
  - Fixed-size static memory and bounded recursion. Tested on PC with 30,000 random/broken inputs under ASan/UBSan.
  - Used when the render server is off, and as a fallback when the server fails.
- **Step-by-step math answers:**
  - **Instructions:** ChatGPT is asked for the full notebook-style solution, one notebook line per equation.
  - **Step label:** the OLED shows the step "n/N" bottom right.
  - **Continuation arrow:** an arrow at the right edge means the same line continues on the next screen (only when an equation had to be split).
  - **Main display:** equations in the text are replaced by "[n]", matching the step on the OLED, and line breaks in the answer start a new display row.
  - **Limits:** MAX_EQS_FOR_RENDERING 20 → 40, MAX_STRLEN_EQS 64 → 200.
- **Hide switch:** SHIFT + DEL in the AI mode switches to the normal calculator (empty screen) and turns the OLED off. SHIFT + DEL again, or the unlock code + =, brings you back exactly where you were (RAM state kept, Wi-Fi stays connected).
- **OLED mostly off:**
  - **After unlock:** status screen for 5 s, then off.
  - **Equations:** on while an equation is shown.
  - **SHIFT + x:** status/battery for 5 s.
  - **Chat view, AC:** equation ↔ 5 s status.
- **Wi-Fi without password:** an empty password means an open network (the STA threshold used to be always WPA2). The setup page (from my partner's fork) has a "no password" checkbox.

## Bug fixes
- **Old answer shown again:** `openAI_process_response_json()`'s return value was ignored, and `answer_buf` in `UI_send_prompt()` is uninitialised stack. When a response couldn't be parsed, the previous answer was shown and saved again, and an uninitialised response ID went into NVS. Now the answer is cleared, the result is checked, and the error is shown. On HTTP errors, OpenAI's error message is displayed.
- **Silent photo failures:** `camera_take_picture()`'s result was ignored. Now it shows "Photo saved (n/4)" / "PHOTO NOT SAVED!", and "No photo attached!" when sending without one. Leftover photos are deleted at boot.
- **Broken JSON:** the typed prompt is now JSON-escaped (a quote or backslash used to break the request).
- **Typos:** `nvs_commit(handle != ESP_OK)` (two places), and the model-list loop used `sizeof(array)` (bytes) as the element count.
- **Battery temperature:** the NTC resistance in `bms_ntc_millivolts_to_millidegrees()` was a uint16_t. A missing/cold NTC (> 65 kΩ) wrapped around to a random "hot" temperature, which caused silent shutdowns. There was also a division by zero when ADC ≥ 3000 mV.
- **BMS debounce:** BMS faults now need 3 bad readings in a row, and the reason is shown on the display.
- **Camera noise:** OV5640 tuning against vertical stripes: gain ceiling 8x, manual denoise, 2 warm-up frames. `CAMERA_NOISE_TUNING 0` turns it off.
- **AI instructions:** answer only the latest message/image; a "never guess" rule (PHOTO UNREADABLE when the question text really can't be read, UNSURE: when not confident); images sent with `"detail":"high"`.

## Settings specific to our build (please check before using them)
- `BMS_IGNORE_TEMPERATURE 1` (AI_calc_battery.h): **temporary**, because our current battery has no NTC wire. Should be `0` with a normal 3-wire battery.
- `BMS_AUTO_SHUTDOWN 0` and `UI_AUTOOFF_ENABLED 0`: we wanted the calculator never to switch itself off. The board's protection IC still protects the cell.
- Camera `set_vflip(1)` / `set_hmirror(0)`: our camera is mounted rotated 180°.
- The setup AP (SSID `test`, password `12345678`) comes from my partner's fork and is hard-coded.
